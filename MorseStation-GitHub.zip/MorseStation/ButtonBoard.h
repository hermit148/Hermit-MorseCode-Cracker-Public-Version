#pragma once
#include "BuildConfig.h"
#include "KeyboardCore.h"
#include <Arduino.h>
#include <Wire.h>
#include <atomic>
namespace hmcbuttons {
static std::atomic<bool> ready{false},morseEnabled{false};
static std::atomic<unsigned> downMask{0},seenMask{0},drops{0};
static QueueHandle_t queue=nullptr;
static bool taskOK=false;
constexpr const char *wiring(){return BUTTONS_USE_MCP23017?"mcp23017":"direct";}
#if BUTTONS_USE_MCP23017
static bool writeRegister(uint8_t reg,uint8_t value){
  Wire.beginTransmission(NAV_I2C_ADDRESS);Wire.write(reg);Wire.write(value);return Wire.endTransmission()==0;
}
static bool readRegister(uint8_t reg,uint8_t &value){
  Wire.beginTransmission(NAV_I2C_ADDRESS);Wire.write(reg);
  if(Wire.endTransmission(false)!=0)return false;
  if(Wire.requestFrom(uint8_t(NAV_I2C_ADDRESS),uint8_t(1),uint8_t(true))!=1)return false;
  value=Wire.read();return true;
}
static bool begin(){
  uint8_t value=0;
  // Recover BANK=0 even if a prior sketch configured BANK=1.
  const uint8_t setup[][2]={{0x05,0},{0x0a,0},{0x02,0},{0x03,0},{0x04,0},{0x05,0},
    {0x14,0},{0x15,0},{0x00,0x1f},{0x01,0},{0x0c,0x1f},{0x0d,0}};
  // Only GPA0-4 are inputs. Unused pins are low outputs, including A7/B7
  // which are output-only on current MCP23017 silicon. Leave these unwired.
  for(const auto &reg:setup)if(!writeRegister(reg[0],reg[1]))return false;
  return readRegister(0x00,value)&&value==0x1f&&readRegister(0x0c,value)&&value==0x1f;
}
#else
static bool begin(){
  for(int pin:NAV_BUTTON_PINS)pinMode(pin,INPUT_PULLUP);
  return true; // GPIO setup, not physical switch detection.
}
#endif
static void task(void*){
  hmcnav::KeyState keys[5];uint32_t retry=0;
  for(;;){
    uint32_t now=millis();
    if(!ready){downMask=0;if(now-retry>=2000){retry=now;ready=begin();}vTaskDelay(pdMS_TO_TICKS(5));continue;}
    uint8_t input=0xff;
#if BUTTONS_USE_MCP23017
    if(!readRegister(0x12,input)){ready=false;downMask=0;for(auto &key:keys)key=hmcnav::KeyState{};vTaskDelay(1);continue;}
#else
    for(unsigned i=0;i<5;++i)if(digitalRead(NAV_BUTTON_PINS[i])==LOW)input&=uint8_t(~(1u<<i));
#endif
    unsigned mask=0;
    for(unsigned i=0;i<5;++i){
      auto event=keys[i].tick(static_cast<hmcnav::Button>(i),!(input&(1u<<i)),now);
      if(keys[i].isDown())mask|=1u<<i;
      if(event.edge==hmcnav::Edge::Release)seenMask.fetch_or(1u<<i);
      if(event.edge!=hmcnav::Edge::None&&xQueueSend(queue,&event,0)!=pdTRUE)++drops;
    }
    downMask=mask;vTaskDelay(pdMS_TO_TICKS(5));
  }
}
}
