#pragma once
#include "OledFont.h"
#include "PostTest.h"
#include "KeyboardCore.h"
#include "WifiCore.h"
#include <stdint.h>

namespace hmcdisplay {
enum class Page : uint8_t { Signal, Device, Network, Ble, Pair, Splash, Post, Keyboard, Menu, Presets, List, Adjust, Confirm, About, BuzzerTest, MicTest, WifiScan, WifiStatus };
// Same vertical-bit pixel layout as the SSD1306 framebuffer. Portable rendering
// allows previews/tests to execute the exact production graphics code.
struct Frame {
  uint8_t data[1024] = {};
  constexpr void pixel(int x, int y, bool on = true) {
    if (x < 0 || x >= 128 || y < 0 || y >= 64) return;
    uint8_t &b = data[x + (y / 8) * 128];
    uint8_t mask = uint8_t(1u << (y % 8));
    b = on ? uint8_t(b | mask) : uint8_t(b & ~mask);
  }
  constexpr bool get(int x, int y) const {
    return x >= 0 && x < 128 && y >= 0 && y < 64 && (data[x+(y/8)*128] & (1u << (y%8)));
  }
  constexpr void box(int x, int y, int w, int h, bool on = true) {
    for (int j = 0; j < h; ++j) for (int i = 0; i < w; ++i) pixel(x+i,y+j,on);
  }
  constexpr void line(int x, int y, int w, bool on = true) { box(x,y,w,1,on); }
  constexpr void outline(int x, int y, int w, int h,bool on=true) {
    line(x,y,w,on); line(x,y+h-1,w,on); box(x,y,1,h,on); box(x+w-1,y,1,h,on);
  }
  constexpr void glyph(int x, int y, char c, unsigned scale = 1, bool on = true) {
    unsigned index = uint8_t(c);
    if (index < 32 || index > 126) index = '?';
    for (unsigned col = 0; col < 5; ++col)
      for (unsigned row = 0; row < 7; ++row)
        if (font[(index-32)*5+col] & (1u << row))
          box(x+col*int(scale),y+row*int(scale),scale,scale,on);
  }
  constexpr void text(int x, int y, const char *s, unsigned scale = 1, bool on = true, unsigned limit = 21) {
    for (unsigned i = 0; i < limit && s[i]; ++i) glyph(x+i*6*int(scale),y,s[i],scale,on);
  }
  constexpr void number(int x, int y, uint32_t n, bool on = true) {
    char s[11] = {}; unsigned count = 0;
    do { s[count++] = char('0'+n%10); n/=10; } while(n && count<10);
    for (unsigned i=0; i<count; ++i) glyph(x+i*6,y,s[count-i-1],1,on);
  }
};
struct Model {
  Page page = Page::Signal;
  uint32_t ms = 0, uptime = 0, heap = 0, minHeap = 0, totalHeap = 0;
  unsigned txWpm = 12, rxWpm = 12, clients = 0, bleCount = 0, countdown = 60, cpuMHz = 160;
  int rssi = 0;
  bool tx = false, signal = false, mic = false, autoSpeed = false, speedLocked = false, online = false;
  uint8_t bleState = 0; // 0 off, 1 idle, 2 scanning, 3 beacon
  char letter = 0;
  char pending[8] = {}, message[121] = {}, ip[16] = {}, ap[33] = {}, ssid[33] = {}, key[25] = {}, wifiPass[64] = {};
  uint8_t wave[64] = {};
  hmcpost::Report post;
  hmcnav::Keyboard keyboard;
  bool navReady=false;
  char presetLabels[6][25]={};
  char rowValues[3][7]={};
  char statusLine[22]={};bool micEnabled=false,micReady=false,micFault=false,buzzerActive=false;unsigned micLevel=0,buzzerCount=0;
  hmcwifi::State wifiState=hmcwifi::State::NotConfigured;hmcwifi::Error wifiError=hmcwifi::Error::None;
  bool wifiScanning=false,wifiScanDone=false,wifiScanFailed=false;char wifiNames[3][33]={};bool wifiSecure[3]={},wifiSupported[3]={true,true,true};unsigned wifiFirst=0;
};
// Layout contract: header 0..9, content 12..50, footer 53..63.
constexpr void icon(Frame &f,int x,int y,unsigned kind,bool on=true){
  if(kind==0){for(int i=0;i<9;++i){f.pixel(x+i,y+i/2,on);f.pixel(x+i,y+8-i/2,on);}f.line(x+2,y+4,7,on);}
  else if(kind==1){f.box(x+4,y,1,6,on);for(int i=0;i<3;++i){f.pixel(x+2+i,y+3+i,on);f.pixel(x+6-i,y+3+i,on);}f.box(x,y+6,1,3,on);f.box(x+8,y+6,1,3,on);f.line(x,y+8,9,on);}
  else if(kind==2){f.outline(x,y,5,4,on);f.box(x+1,y,3,2,!on);for(int i=0;i<5;++i){f.pixel(x+3+i,y+3+i,on);f.pixel(x+4+i,y+3+i,on);}}
  else if(kind==3){f.outline(x+2,y+2,5,5,on);f.pixel(x+4,y+4,on);f.box(x+4,y,1,2,on);f.box(x+4,y+7,1,2,on);f.line(x,y+4,2,on);f.line(x+7,y+4,2,on);f.pixel(x+1,y+1,on);f.pixel(x+7,y+1,on);f.pixel(x+1,y+7,on);f.pixel(x+7,y+7,on);}
  else if(kind==4){f.outline(x,y+1,9,7,on);for(int i=0;i<3;++i){f.pixel(x+2+i*2,y+3,on);f.pixel(x+2+i*2,y+5,on);}}
  else if(kind==5){f.outline(x,y,9,9,on);f.outline(x+2,y,5,4,on);f.line(x+2,y+6,5,on);}
  else if(kind==6){f.line(x,y+1,9,on);f.line(x+2,y,5,on);f.outline(x+1,y+2,7,7,on);f.box(x+3,y+4,1,3,on);f.box(x+5,y+4,1,3,on);}
  else if(kind==7){f.line(x,y+4,9,on);for(int i=0;i<4;++i){f.pixel(x+i,y+4-i,on);f.pixel(x+i,y+4+i,on);}}
  else if(kind==8){for(int i=0;i<4;++i)f.box(x+i*2,y+7-i*2,1,i*2+1,on);}
  else if(kind==9){f.box(x+4,y,1,9,on);for(int i=0;i<5;++i){f.pixel(x+4+i/2,y+i,on);f.pixel(x+4+i/2,y+8-i,on);f.pixel(x+i,y+2+i,on);f.pixel(x+4-i,y+2+i,on);}}
  else if(kind==10){f.outline(x+2,y+1,5,7,on);for(int i=0;i<3;++i){f.line(x,y+2+i*2,2,on);f.line(x+7,y+2+i*2,2,on);}}
  else if(kind==12){f.box(x,y+3,3,3,on);for(int i=0;i<4;++i)f.box(x+2+i,y+3-i,1,3+i*2,on);f.box(x+8,y+2,1,5,on);}
  else if(kind==13){f.outline(x+2,y+2,5,5,on);f.pixel(x+4,y,on);f.pixel(x+4,y+8,on);f.pixel(x,y+4,on);f.pixel(x+8,y+4,on);}
  else if(kind==14){f.line(x+2,y,5,on);f.pixel(x+1,y+1,on);f.pixel(x+7,y+1,on);f.box(x,y+2,1,5,on);f.box(x+8,y+2,1,5,on);f.line(x+1,y+7,7,on);f.pixel(x+4,y+5,on);f.pixel(x+5,y+4,on);f.pixel(x+6,y+3,on);}
  else if(kind==15){f.outline(x+3,y,3,6,on);f.line(x+1,y+6,7,on);f.box(x+4,y+6,1,3,on);f.line(x+2,y+8,5,on);}
  else if(kind==16){f.outline(x,y,9,9,on);f.pixel(x+2,y+4,on);f.pixel(x+3,y+5,on);f.pixel(x+4,y+4,on);f.pixel(x+5,y+3,on);f.pixel(x+6,y+2,on);}
  else if(kind==17){f.outline(x+2,y,5,5,on);f.box(x+1,y+4,7,5,on);f.pixel(x+4,y+5,!on);f.pixel(x+4,y+6,!on);}
  else if(kind==18){f.outline(x,y,9,7,on);f.pixel(x+2,y+7,on);f.pixel(x+1,y+8,on);f.pixel(x+2,y+3,on);f.pixel(x+4,y+3,on);f.pixel(x+6,y+3,on);}
  else if(kind==20){f.outline(x,y+3,5,5,on);f.outline(x+4,y,5,5,on);f.pixel(x+3,y+5,on);f.pixel(x+4,y+4,on);f.pixel(x+5,y+3,on);}
  else{f.outline(x,y,9,9,on);f.pixel(x+4,y+2,on);f.box(x+4,y+4,1,3,on);}
}
constexpr void radioIcon(Frame &f,const Model &m){
  unsigned bars=m.online?(m.rssi>-55?4:m.rssi>-67?3:m.rssi>-78?2:1):4;
  for(unsigned i=0;i<bars;++i){int x=110+i*4,y=7-i*2;if(m.online)f.box(x,y,2,2+i*2,false);else f.outline(x,y,2,2+i*2,false);}
  if(!m.online){bool joining=m.wifiState==hmcwifi::State::Connecting;if(!joining||(m.ms/350)%2==0)for(int i=0;i<8;++i){f.pixel(112+i,1+i,false);if(!joining)f.pixel(119-i,1+i,false);}}
}
constexpr void header(Frame &f,const char *label,const Model &m){f.box(0,0,128,10);f.text(3,2,label,1,false,17);radioIcon(f,m);}
constexpr void backFooter(Frame &f,const char *hint="SEL BACK"){
  f.line(0,53,128);f.box(0,54,47,10);icon(f,3,54,7,false);f.text(15,56,"Back",1,false,4);f.text(52,56,hint,1,true,12);
}
constexpr bool noticeVisible(const Model &m){return m.keyboard.notice!=hmcnav::Notice::Ready&&m.ms-m.keyboard.changedAt<1800;}
constexpr unsigned rowIcon(hmcnav::Screen s,unsigned row){
  using hmcnav::Screen;if(row==hmcnav::menuCount(s)-1)return 7;
  if(s==Screen::SendMenu)return row==0?4:row==1?5:6;
  if(s==Screen::ReceiveMenu)return row==0?1:row==1?16:6;
  if(s==Screen::Tools)return row==0?8:row==1?9:10;
  if(s==Screen::System)return row==0?16:row==1?10:11;
  if(s==Screen::Setup)return row==0?12:row==1?13:20;
  if(s==Screen::SignalSetup)return row==0?14:row==1?12:1;
  if(s==Screen::DisplaySetup)return row==0?13:row==1?3:12;
  if(s==Screen::InputSetup)return row==0?14:15;
  if(s==Screen::Connections)return row==0?8:row==1?0:18;
  if(s==Screen::WifiSetup)return row==0?8:row==1?4:11;
  if(s==Screen::WifiManual)return row==0?8:row==1?17:11;
  if(s==Screen::TelegramSetup)return row==0?17:row==1?18:3;
  if(s==Screen::DiscordSetup)return row==0?20:row==1?3:6;
  if(s==Screen::TelegramOptions||s==Screen::DiscordOptions)return row==0?0:row==1?1:6;
  if(s==Screen::Tests)return row==0?16:row==1?12:15;
  return row==2?6:9;
}
constexpr void row(Frame &f,unsigned pos,const char *label,unsigned kind,bool selected,const char *value=""){
  int y=13+int(pos)*10;if(selected)f.box(1,y-1,126,9);icon(f,4,y-1,kind,!selected);f.text(17,y,label,1,!selected,11);
  unsigned n=0;while(n<6&&value[n])++n;if(n)f.text(126-int(n)*6,y,value,1,!selected,6);
}
constexpr void networkName(Frame &f,const char *s){unsigned n=0;while(n<32&&s[n])++n;if(n<=21){f.text(1,13,s,1,true,21);return;}unsigned split=21;for(unsigned i=1;i<=21;++i)if(s[i]==' ')split=i;f.text(1,13,s,1,true,split);f.text(1,22,s+split+(s[split]==' '?1:0),1,true,21);}
constexpr Frame render(const Model &m){
  Frame f;using hmcnav::Screen;using hmcnav::Notice;
  if(m.page==Page::Menu){
    header(f,"MORSE CRACKER",m);
    for(unsigned i=0;i<4;++i){int x=2+(i%2)*64,y=12+(i/2)*21;bool selected=m.keyboard.menu==i;
      if(selected)f.box(x,y,60,19);else f.outline(x,y,60,19);
      icon(f,x+3,y+5,i,!selected);f.text(x+16,y+6,hmcnav::homeLabel(i),1,!selected,7);}
    f.line(0,53,128);f.text(1,56,"ARROWS MOVE  SEL OPEN",1,true,21);return f;
  }
  if(m.page==Page::List){
    auto screen=m.keyboard.screen;header(f,hmcnav::title(screen),m);unsigned count=hmcnav::menuCount(screen);
    for(unsigned i=0;i<count;++i)row(f,i==count-1?3:i,hmcnav::menuLabel(screen,i),rowIcon(screen,i),m.keyboard.menu==i,i<3?m.rowValues[i]:"");
    f.line(0,53,128);f.text(1,56,noticeVisible(m)?hmcnav::noticeText(m.keyboard.notice):m.statusLine[0]?m.statusLine:"UP/DN MOVE  SEL OPEN",1,true,21);return f;
  }
  if(m.page==Page::WifiScan){
    header(f,"SELECT WI-FI",m);
    if(m.wifiScanning){icon(f,5,17,8);f.text(23,15,"SCANNING...",1,true,17);f.text(3,29,"2.4 GHz networks",1,true,20);}
    else{for(unsigned i=0;i<3;++i){unsigned item=m.wifiFirst+i;if(item>m.keyboard.wifiCount)break;bool rescan=item==m.keyboard.wifiCount,selected=m.keyboard.menu==item;int y=13+i*10;
      if(selected)f.box(1,y-1,126,9);icon(f,4,y-1,rescan?8:!m.wifiSupported[i]?11:m.wifiSecure[i]?17:8,!selected);
      const char *name=rescan?"Rescan":m.wifiNames[i];unsigned n=0;while(name[n]&&n<32)++n;uint32_t age=m.ms-m.keyboard.changedAt;unsigned off=selected&&n>18&&age>=1600?((age-1600)/500)%(n-17):0;f.text(17,y,name+off,1,!selected,18);}}
    row(f,3,"Back",7,m.keyboard.menu==m.keyboard.wifiCount+1);f.line(0,53,128);
    f.text(1,56,noticeVisible(m)?hmcnav::noticeText(m.keyboard.notice):m.wifiScanning?"PLEASE WAIT":m.wifiScanFailed?"SCAN FAILED > RESCAN":m.wifiScanDone&&!m.keyboard.wifiCount?"NONE FOUND > RESCAN":"LOCK = PASSWORD",1,true,21);return f;
  }
  if(m.page==Page::WifiStatus){
    header(f,"WI-FI STATUS",m);f.text(3,13,hmcwifi::label(m.wifiState),1,true,21);
    unsigned n=0;while(m.ssid[n]&&n<32)++n;f.text(3,24,m.ssid[0]?m.ssid:"Choose a network",1,true,20);if(n>20)f.text(3,33,m.ssid+20,1,true,12);
    f.text(3,43,m.online?m.ip:hmcwifi::message(m.wifiError)[0]?hmcwifi::message(m.wifiError):"Setup > Scan Wi-Fi",1,true,21);backFooter(f,"RIGHT RETRY");return f;
  }
  if(m.page==Page::Keyboard){
    f.box(0,0,128,10);f.text(3,2,m.keyboard.fieldTitle(),1,false,12);
    char count[8]={};unsigned n=m.keyboard.typedLength(),limit=m.keyboard.limit(),at=0;char rev[4]={};unsigned digits=0;do{rev[digits++]='0'+n%10;n/=10;}while(n);while(digits)count[at++]=rev[--digits];count[at++]='/';digits=0;do{rev[digits++]='0'+limit%10;limit/=10;}while(limit);while(digits)count[at++]=rev[--digits];f.text(85,2,count,1,false,7);
    f.outline(1,11,126,18);unsigned length=m.keyboard.typedLength(),start=length>39?length-39:0;
    if(noticeVisible(m))f.text(4,16,hmcnav::noticeText(m.keyboard.notice),1,true,20);
    else{
      const char *text=m.keyboard.typedText();for(unsigned i=start;i<length;++i){unsigned pos=i-start;char c=m.keyboard.secret()&&!(i+1==length&&m.keyboard.lastTypedAt&&m.ms-m.keyboard.lastTypedAt<900)?'*':text[i];f.glyph(4+(pos%20)*6,12+(pos/20)*9,c);}
      unsigned pos=length-start;if((m.ms/500)%2==0)f.box(4+(pos%20)*6,12+(pos/20)*9,1,7);
      if(start){f.pixel(2,14);f.pixel(2,16);f.pixel(1,15);}
    }
    for(unsigned i=0;i<27;++i){int x=1+(i%9)*14,y=31+(i/9)*8;bool selected=i==m.keyboard.cursor;if(selected)f.box(x,y,13,8);auto label=m.keyboard.caption(i);unsigned chars=label.text[1]?2:1;f.text(x+(chars==2?1:4),y,label.text,1,!selected,2);}
    for(unsigned i=27;i<33;++i){int x=1+(i-27)*21,y=56;bool selected=i==m.keyboard.cursor;if(selected)f.box(x,y,20,8);bool on=!selected;
      if(i==27||i==28){auto label=m.keyboard.caption(i);f.text(x+(i==27?4:1),y,label.text,1,on,3);}
      else if(i==29){f.line(x+7,y,8,on);f.box(x+14,y,1,7,on);f.line(x+7,y+6,8,on);for(int j=0;j<4;++j){f.pixel(x+4+j,y+3-j,on);f.pixel(x+4+j,y+3+j,on);}f.pixel(x+9,y+2,on);f.pixel(x+11,y+2,on);f.pixel(x+10,y+3,on);f.pixel(x+9,y+4,on);f.pixel(x+11,y+4,on);}
      else if(i==30){f.line(x+6,y,9,on);f.outline(x+7,y+1,7,6,on);f.box(x+9,y+2,1,3,on);f.box(x+11,y+2,1,3,on);}
      else if(i==31){if(m.keyboard.field!=hmcnav::Field::Message){f.pixel(x+6,y+3,on);f.pixel(x+7,y+4,on);for(int j=0;j<5;++j)f.pixel(x+8+j,y+5-j,on);}else if(m.tx)f.box(x+7,y+1,6,6,on);else for(int j=0;j<7;++j)f.box(x+7+j,y+j/2,1,7-j,on);}
      else{f.line(x+6,y+3,9,on);for(int j=0;j<4;++j){f.pixel(x+6+j,y+3-j,on);f.pixel(x+6+j,y+3+j,on);}}
    }
    return f;
  }
  if(m.page==Page::Presets){
    header(f,"PRESETS",m);f.number(87,2,m.keyboard.presetPage+1,false);f.text(93,2,"/2",1,false,2);
    for(unsigned i=0;i<3;++i){unsigned item=m.keyboard.presetPage*3+i;const char *name=m.presetLabels[item];if(!name[0])name="Empty slot";int y=13+i*10;bool selected=m.keyboard.menu==item;
      if(selected)f.box(1,y-1,126,9);f.number(4,y,item+1,!selected);unsigned n=0;while(n<24&&name[n])++n;uint32_t age=m.ms-m.keyboard.changedAt;unsigned offset=selected&&n>17&&age>=1600?((age-1600)/500)%(n-16):0;f.text(17,y,name+offset,1,!selected,17);}
    row(f,3,"Back",7,m.keyboard.menu==6);f.line(0,53,128);f.text(1,56,noticeVisible(m)?hmcnav::noticeText(m.keyboard.notice):"SEL LOAD  RIGHT PLAY",1,true,21);return f;
  }
  if(m.page==Page::Adjust){
    const char *name=m.keyboard.setting==hmcnav::Setting::Speed?"SPEED / WPM":m.keyboard.setting==hmcnav::Setting::Tone?"TONE / HZ":m.keyboard.setting==hmcnav::Setting::Contrast?"BRIGHTNESS":"MIC LEVEL / DB";
    header(f,name,m);f.text(23,13,noticeVisible(m)?hmcnav::noticeText(m.keyboard.notice):"UP/DN ADJUST",1,true,17);
    unsigned n=m.keyboard.editValue,digits=n>=1000?4:n>=100?3:n>=10?2:1;char value[5]={};for(unsigned i=0;i<digits;++i){value[digits-i-1]='0'+n%10;n/=10;}
    f.text((128-int(digits)*12)/2,25,value,2,true,4);f.text(14,42,"RIGHT: SAVE / BACK",1,true,19);
    bool save=m.keyboard.menu==0;f.outline(2,52,59,12);f.outline(67,52,59,12);if(save)f.box(2,52,59,12);else f.box(67,52,59,12);f.text(18,55,"Save",1,!save,4);f.text(83,55,"Back",1,save,4);return f;
  }
  if(m.page==Page::Confirm){
    header(f,"CONFIRM CLEAR",m);f.text(4,14,m.keyboard.clearTarget==1?"Clear RX input?":m.keyboard.clearTarget>=3?"Remove saved setup?":m.keyboard.clearTarget==2?"Clear typed text?":"Clear the draft?",1,true,21);f.text(4,25,"Cannot undo this",1,true,21);
    row(f,2,"Clear",6,m.keyboard.menu==0);row(f,3,"Back",7,m.keyboard.menu==1);f.line(0,53,128);f.text(1,56,"ARROWS PICK  SEL OK",1,true,21);return f;
  }
  if(m.page==Page::Splash){
    f.outline(0,0,128,64);f.text(40,3,"HERMIT'S",1,true,8);f.text(34,15,"MORSE",2,true,5);f.text(43,32,"CRACKER",1,true,7);
    unsigned t=m.ms>2000?2000:m.ms;f.line(8,50,112);unsigned plane=8+t*103/2000;icon(f,plane,42,0);f.line(8,48,t*103/2000);
    f.text(25,55,t<650?"STARTING...":t<1400?"CHECKING IO":hmcpost::missing(m.post)?"CHECK HW":"READY",1,true,17);return f;
  }
  if(m.page==Page::BuzzerTest){header(f,"BUZZER TEST",m);icon(f,4,17,12);f.text(23,14,m.buzzerActive?"PLAYING TONES":"SELECT TO PLAY",1,true,17);f.text(3,29,"Completed:",1,true,10);f.number(69,29,m.buzzerCount);f.text(3,42,"Confirm by listening",1,true,20);backFooter(f,"SEL PLAY");return f;}
  if(m.page==Page::MicTest){header(f,"MIC TEST",m);icon(f,4,16,15);if(!m.micEnabled){f.text(23,15,"DISABLED",1,true,16);f.text(3,30,"Microphone required",1,true,20);f.text(3,42,"See wiring guide",1,true,20);}else if(!m.micReady){f.text(23,15,m.micFault?"DRIVER FAILED":"STARTING DRIVER",1,true,17);}else{f.text(23,15,m.signal?"TONE DETECTED":"LISTENING",1,true,17);f.outline(3,30,122,10);unsigned width=m.micLevel>100?118:m.micLevel*118/100;f.box(5,32,width,6);f.text(3,44,"Level / tone check",1,true,20);}backFooter(f);return f;}
  if(m.page==Page::Pair||m.page==Page::Network){
    header(f,"WI-FI ACCESS",m);networkName(f,m.ap);f.text(2,33,"PASS",1,true,4);f.text(33,33,m.wifiPass,1,true,15);f.text(2,44,"192.168.4.1",1,true,20);backFooter(f);return f;
  }
  if(m.page==Page::Post){
    header(f,"HW CHECK",m);unsigned page=m.keyboard.postPage%5;f.number(84,2,page+1,false);f.text(90,2,"/5",1,false,2);
    for(unsigned r=0;r<3;++r){unsigned item=page*3+r;if(item>=hmcpost::Count)break;int y=13+r*10;auto status=m.post.items[item];f.text(2,y,hmcpost::name(item),1,true,11);f.text(78,y,hmcpost::label(status),1,true,8);}
    f.text(2,44,"UP/DN: MORE ITEMS",1,true,20);backFooter(f);return f;
  }
  if(m.page==Page::Signal){
    header(f,m.tx?"SENDING":m.mic?"LISTEN MIC":"LISTEN KEY",m);f.number(74,2,m.tx?m.txWpm:m.rxWpm,false);f.text(88,2,"WPM",1,false,3);
    if(m.letter&&m.letter!=' ')f.glyph(4,15,m.letter,3);else f.text(4,19,"--",2,true,2);
    f.text(29,14,m.tx?"PLAYING":m.signal?"SIGNAL ON":"READY",1,true,15);f.text(29,25,m.pending[0]?m.pending:". . .",1,true,8);
    f.text(29,35,m.autoSpeed?(m.speedLocked?"AUTO LOCK":"AUTO LEARN"):"MANUAL SPEED",1,true,15);
    f.line(0,42,128);unsigned n=0;while(n<120&&m.message[n])++n;
    f.text(2,44,n?m.message+(n>20?n-20:0):"Waiting for Morse",1,true,20);
    backFooter(f,m.tx?"PLAYING":"SEL KEY >END");return f;
  }
  if(m.page==Page::Device){
    header(f,"DEVICE INFO",m);f.text(3,14,"HMC 3.3",1,true,8);f.number(69,14,m.cpuMHz);f.text(92,14,"MHZ",1,true,3);
    f.text(3,26,"FREE",1,true,4);f.number(36,26,m.heap/1024);f.text(61,26,"K",1,true,1);f.outline(77,25,48,9);unsigned w=m.totalHeap?m.heap*44/m.totalHeap:0;if(w>44)w=44;f.box(79,27,w,5);
    f.text(3,38,"MIN",1,true,3);f.number(27,38,m.minHeap/1024);f.text(52,38,"K",1,true,1);f.text(67,38,"UP",1,true,2);f.number(85,38,m.uptime/60);f.text(116,38,"M",1,true,1);backFooter(f);return f;
  }
  if(m.page==Page::About){header(f,"ABOUT",m);f.text(3,14,"HERMIT'S",1,true,12);f.text(3,25,"MORSE CRACKER",1,true,20);f.text(3,36,"HERMIT AKA ASHWIN",1,true,20);f.text(3,45,"HMC 3.3 / ESP32-C3",1,true,20);backFooter(f);return f;}
  header(f,"BLUETOOTH",m);icon(f,5,19,9);f.text(23,14,m.bleState==3?"BEACON ACTIVE":m.bleState==2?"SCANNING":m.bleState==1?"READY":"RADIO OFF",1,true,16);f.text(23,28,"SEEN",1,true,4);f.number(55,28,m.bleCount);f.text(3,42,"Tools > Bluetooth",1,true,21);backFooter(f);return f;
}
}
