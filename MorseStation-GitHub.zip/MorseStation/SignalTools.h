#pragma once
#include <stdint.h>
#include <stddef.h>

namespace morse {
// A single pulse length is ambiguous (dot or dash). Require both clusters
// before changing receive timing; ignore glitches and implausibly long holds.
class SpeedEstimator {
  uint16_t samples[24] = {};
  unsigned count = 0, next = 0;
  uint16_t estimate = 100;
  bool locked = false;
public:
  constexpr void reset(unsigned wpm = 12) {
    if (wpm < 5) wpm = 5;
    if (wpm > 30) wpm = 30;
    count = next = 0; estimate = 1200 / wpm; locked = false;
  }
  constexpr bool observe(uint32_t ms) {
    if (ms < 30 || ms > 850) return false;
    samples[next] = ms; next = (next + 1) % 24;
    if (count < 24) ++count;
    if (count < 6) return false;
    uint16_t sorted[24] = {};
    for (unsigned i = 0; i < count; ++i) sorted[i] = samples[i];
    for (unsigned i = 1; i < count; ++i) {
      uint16_t v = sorted[i]; unsigned j = i;
      while (j && sorted[j-1] > v) { sorted[j] = sorted[j-1]; --j; }
      sorted[j] = v;
    }
    // Trim the extremes so a single stray edge cannot dominate acquisition.
    float low = sorted[1], high = sorted[count-2];
    if (high < low * 2.2f || high > low * 4.2f) return false;
    float split = (low + high) / 2, dots = 0, dashes = 0;
    unsigned nd = 0, nh = 0;
    for (unsigned i = 0; i < count; ++i) {
      if (sorted[i] < low * .65f || sorted[i] > high * 1.35f) continue;
      if (sorted[i] < split) { dots += sorted[i]; ++nd; }
      else { dashes += sorted[i]; ++nh; }
    }
    if (nd < 2 || nh < 2) return false;
    float dot = dots / nd, dash = dashes / nh;
    if (dash < dot * 2.2f || dash > dot * 3.8f) return false;
    float unit = (dot + dash / 3) / 2;
    if (unit < 38 || unit > 250) return false;
    estimate = uint16_t(locked ? (estimate + unit) / 2 + .5f : unit + .5f);
    if (estimate < 40) estimate = 40;
    if (estimate > 240) estimate = 240;
    locked = true;
    return true;
  }
  constexpr bool acquired() const { return locked; }
  constexpr unsigned sampleCount() const { return count; }
  constexpr unsigned unitMs() const { return estimate; }
  constexpr unsigned wpm() const { return (1200 + estimate / 2) / estimate; }
};
struct SignalSegment {
  uint32_t id = 0, at = 0, duration = 0;
  bool on = false, tx = false;
};
class SignalTimeline {
public:
  static constexpr unsigned capacity = 64;
  SignalSegment items[capacity] = {};
  unsigned count = 0;
  uint32_t next = 1;
  constexpr void add(uint32_t at, uint32_t duration, bool on, bool tx) {
    if (!duration) return;
    items[(next - 1) % capacity] = {next, at, duration, on, tx};
    ++next; if (count < capacity) ++count;
  }
};
}
