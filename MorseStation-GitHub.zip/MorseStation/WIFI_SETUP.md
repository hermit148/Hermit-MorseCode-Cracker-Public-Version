# Wi-Fi setup / HMC 3.3

The ESP32-C3 scans **2.4 GHz** Wi-Fi. The device AP stays enabled during router
setup: **HERMITS MORSECODE CRACKER**, password/web key **HermitCrack**,
http://192.168.4.1. Router connection may move the AP to the router's channel;
rejoin the device AP if the browser loses connection.

## Web UI

Open Settings > Wi-Fi, press **Scan Wi-Fi**, select a network, enter its password
and press **Connect Wi-Fi**. This saves Wi-Fi settings independently of Telegram
and the rest of the settings form. Wait for **Wi-Fi connected** and the router IP.
Missing/short passwords are rejected before a connection attempt. Open networks
are marked Open and do not request a password. Unsupported security is disabled.

The status icon/text at the top shows Connected, Connecting or Not connected.
The Wi-Fi card explains a failure such as network not found, password required,
check password or connection timed out. Router connection does not prove that
internet access or Telegram delivery works; captive portals may still block it.

Scanning is asynchronous, limited to once per 10 seconds, and retains up to 16
distinct networks with the strongest signal. Duplicate SSIDs are combined. A
hidden or weak network can be entered manually. Scans do not reveal passwords.
Changing networks never reuses another network's saved password. For the same
saved network, a blank password uses its saved password; enter a replacement
to change it. Show password applies only to newly entered browser text.

## OLED

Setup > Connections > Wi-Fi:

- **Scan Wi-Fi:** scan, choose a network, enter its password with the on-screen
  keyboard, and select the checkmark Save key. Open networks connect directly.
  Back cancels an unsaved password. Long selected names scroll. Up/Down moves
  through results and Rescan; Back remains pinned at the bottom.
- **Manual setup:** SSID, Password, AP details and Back. Used for hidden networks.
  Changing the SSID clears the previous password; save the new password next.
- **Link status:** current connection state, network name, router IP or failure.
  Right retries the saved connection; Select/Left returns.

Home and other standard page headers reserve the top-right corner for router
status: solid signal bars when connected, a crossed icon when disconnected and
an animated mark while connecting. The message/credential keyboard reserves its
header for field name and character count. No extra display or pins are required.

Connection attempts time out after 20 seconds. Failed/dropped connections retry
at bounded intervals. A scanned protected network with no saved password shows
Password required and waits for input. Local Morse operation remains available.

## Telegram and diagnostics

Telegram's configured label describes saved credentials. Forward TX and RX are
separate switches. When configured but offline, the dashboard says Waiting for
Wi-Fi connection; after joining it can show Waiting for clock synchronization.
The Send test message button reports a prerequisite error immediately if Wi-Fi
or the clock is unavailable. A completed POST/buzzer sound is never forwarded.

Serial Monitor at 115200, Newline enabled:

- **NET:** connection, saved-password presence, IP, clock, Telegram configuration
  and forwarding states, and scan count. No token or password is printed.
- **WIFISCAN:** start a scan; NET shows completion/count.
- **HOME:** return to the icon home screen.

Implementation uses the installed Arduino-ESP32 asynchronous scan API and
station status, with the recovery AP retained. API reference:
[Espressif Wi-Fi documentation](https://docs.espressif.com/projects/arduino-esp32/en/latest/api/wifi.html).
