// Adapt the existing host suite for execution on the actual ESP32 test task.
// Assertions record the failure line instead of aborting/resetting the board.
const fs=require('fs'),path=require('path'),root=path.resolve(__dirname,'..');
let core=fs.readFileSync(root+'/tests/test_core.cpp','utf8');
core=core.replace('using namespace morse;','#undef assert\n#define assert(test) do { ++qaCoreChecks; if (!(test)) { qaCoreFailure=__LINE__; return; } } while(0)\nusing namespace morse;');
core=core.replace('int main()','void qaCoreTests()').replace('elapsed++;','elapsed++;\n    if ((elapsed & 4095)==0) vTaskDelay(1);').replace('  puts("PASS:','  Serial.println("PASS:');
core+='\n#undef assert\n';
if(!core.includes('void qaCoreTests()'))throw Error('Core suite entry point not found');
const output=root+'/tests/target_core.inc';
if(!fs.existsSync(output)||fs.readFileSync(output,'utf8')!==core)fs.writeFileSync(output,core);
