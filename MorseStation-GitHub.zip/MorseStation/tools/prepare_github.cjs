// Package only the non-mic and mic/direct-button releases. No device access.
// node tools/prepare_github.cjs [--output <new empty MorseStation directory>]
const fs=require('fs'),path=require('path'),crypto=require('crypto'),assert=require('assert/strict');
const root=path.resolve(__dirname,'..');
const digestBytes=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const digest=file=>digestBytes(fs.readFileSync(file));
const outputIndex=process.argv.indexOf('--output');
if(outputIndex>=0)assert(process.argv[outputIndex+1],'Pass a destination after --output');
const stamp=new Date().toISOString().replace(/[:.]/g,'-');
const stage=outputIndex<0?path.resolve(root,'github-ready','release-'+stamp,'MorseStation'):path.resolve(process.argv[outputIndex+1]);
assert.equal(path.basename(stage),'MorseStation','Keep the Arduino sketch folder named MorseStation');
assert(stage!==root&&!root.startsWith(stage+path.sep),'Output must not replace the source directory');
assert(!fs.existsSync(stage)||fs.readdirSync(stage).length===0,'Destination contains files; choose a new empty folder');
const variants=[
 {name:'Hermits-Morse-Cracker-C3-Direct-Buttons.bin',info:'firmware/build-info.json',variant:'direct-buttons',microphone:false,app:'firmware/MorseStation.ino.bin'},
 {name:'Hermits-Morse-Cracker-C3-Mic-Direct-Buttons.bin',info:'firmware/mic-direct/build-info.json',variant:'mic-direct-buttons',microphone:true,app:'firmware/mic-direct/MorseStation.ino.bin'}
];
const binaryHashes=JSON.parse(fs.readFileSync(root+'/firmware/SHA256SUMS.json','utf8'));
const verified=[];
for(const v of variants){
 const image=fs.readFileSync(root+'/firmware/'+v.name),info=JSON.parse(fs.readFileSync(root+'/'+v.info,'utf8'));
 assert.equal(digestBytes(image),binaryHashes[v.name],'Firmware SHA mismatch: '+v.name);
 assert.equal(info.variant,v.variant);assert.equal(info.features.microphone,v.microphone);assert.equal(info.features.buttonWiring,'direct');
 assert(info.nativeUsbCdc);assert.equal(info.flashBytes,0x400000);assert.equal(info.partitionBytes,0x300000);
 assert.equal(image.length,0x400000);assert.equal(image[0],0xe9);assert.equal(image[0x10000],0xe9);
 assert.equal(image.readUInt16LE(0x1000c),5,'Application must target ESP32-C3');
 assert(image.subarray(0x9000,0xe000).every(b=>b===255),'Public image contains saved NVS');
 assert(info.appBytes>0&&info.appBytes<=0x300000,'Application exceeds its partition');
 for(const [file,hash]of Object.entries(info.sourceHashes))assert.equal(digest(root+'/'+file),hash,'Source differs from compiled image: '+file);
 const application=image.subarray(0x10000,0x10000+info.appBytes),appHash=digestBytes(application);
 if(fs.existsSync(root+'/'+v.app))assert(application.equals(fs.readFileSync(root+'/'+v.app)),'Merged/application mismatch');
 else assert.equal(appHash,info.applicationSha256,'Missing or incorrect application hash');
 if(v.microphone){assert.deepEqual(info.features.i2sPins,{bclk:2,ws:21,data:20});assert.equal(info.features.requiredGpio2PullupOhms,10000);}
 verified.push({v,image,info:{...info,completeImage:v.name,flashOffset:'0x0',mergedSha256:digestBytes(image),applicationSha256:appHash}});
}
const top=['README.md','.gitignore','partitions.csv','sketch.yaml','libraries.txt','diagram.json','wokwi.toml','OLED_FONT_LICENSE.txt','OLED_MENU_PLAN.md','OLED_GUIDE.md','POST_GUIDE.md','WIFI_SETUP.md','WIRING_KEYBOARD.md','web.html'];
for(const name of fs.readdirSync(root))if(/\.(h|cpp|ino)$/.test(name))top.push(name);
const docs=['GALLERY.md','PUBLISHING.md','VALIDATION.md','WEB_FLASHING.md','WIRING.md','WIRING_MIC_DIRECT.md','WOKWI.md'];
const toolFiles=['build_cached.cjs','check_variants.cjs','embed_ui.cjs','export_docs.cjs','get_chat_id.py','make_direct_mic_wiring.cjs','make_wiring.cjs','prepare_github.cjs','prepare_target_core.cjs','preview_oled.cjs'];
const files=new Set([...top,...docs.map(f=>'docs/'+f),...toolFiles.map(f=>'tools/'+f)]);
function walk(dir){for(const e of fs.readdirSync(root+'/'+dir,{withFileTypes:true})){assert(!e.isSymbolicLink(),'Do not package symlinks');const file=dir+'/'+e.name;if(e.isDirectory())walk(file);else if(e.isFile())files.add(file);}}
for(const dir of ['tests','simulation'])walk(dir);
const gallery=JSON.parse(fs.readFileSync(root+'/docs/assets/gallery.json','utf8'));
for(const entry of [...gallery.web,...gallery.oled]){assert(!/mcp|expander/i.test(entry.file+entry.title),'Expander screenshot in gallery');files.add('docs/assets/'+entry.file);}
for(const file of ['hero.png','oled-frames.bin','gallery.json','wiring.png','wiring.svg','wiring.json','wiring-mic-direct.png','wiring-mic-direct.svg','wiring-mic-direct.json'])files.add('docs/assets/'+file);
assert([...files].every(f=>!/(^|\/)(\.env|credentials\.json)$|nvs.*\.bin$|\.log$|mic-mcp|WIRING_MCP|WIRING_FULL_MIC|make_full_wiring/i.test(f)),'Unwanted private/expander artifact');
fs.mkdirSync(stage,{recursive:true});
for(const file of files){fs.mkdirSync(path.dirname(stage+'/'+file),{recursive:true});fs.copyFileSync(root+'/'+file,stage+'/'+file);}
const publicHashes={};
for(const {v,image,info}of verified){
 fs.mkdirSync(path.dirname(stage+'/'+v.info),{recursive:true});fs.writeFileSync(stage+'/firmware/'+v.name,image);fs.writeFileSync(stage+'/'+v.info,JSON.stringify(info,null,2)+'\n');
 files.add('firmware/'+v.name);files.add(v.info);publicHashes[v.name]=digestBytes(image);
}
fs.writeFileSync(stage+'/firmware/SHA256SUMS.json',JSON.stringify(publicHashes,null,2)+'\n');files.add('firmware/SHA256SUMS.json');
const headings=text=>new Set([...text.matchAll(/^#{1,6}\s+(.+)$/gm)].map(m=>m[1].toLowerCase().replace(/[`*]/g,'').replace(/[^\p{L}\p{N}_ -]/gu,'').replaceAll(' ','-')));
let checkedLinks=0;
for(const file of [...files].filter(f=>f.endsWith('.md'))){const text=fs.readFileSync(stage+'/'+file,'utf8');
 assert(!/WIRING_MCP|WIRING_FULL_MIC|mic-mcp|Mic-MCP23017\.bin/.test(text),'Expander variant still documented: '+file);
 for(const m of text.matchAll(/!?\[[^\]]*\]\(([^)]+)\)/g)){let target=m[1].trim().split(/\s+"/)[0];if(/^(https?:|mailto:|data:)/.test(target))continue;target=target.replace(/^<|>$/g,'');const [name,anchor]=target.split('#'),resolved=path.resolve(path.dirname(stage+'/'+file),decodeURIComponent(name||path.basename(file)));
  assert(resolved.startsWith(stage+path.sep),'Link escapes package');assert(fs.existsSync(resolved),'Broken link: '+file+' -> '+target);
  if(anchor&&resolved.endsWith('.md'))assert(headings(fs.readFileSync(resolved,'utf8')).has(decodeURIComponent(anchor)),'Broken heading: '+file+' -> '+target);++checkedLinks;
 }
}
for(const file of files){assert(!/mcp|expander/i.test(file),'Unwanted expander filename: '+file);if(/\.(md|cjs|py|json|toml|yaml|ino|cpp|h|html|txt)$/.test(file))assert(!/C:[\\/]+Users[\\/]+ashwi/i.test(fs.readFileSync(stage+'/'+file,'utf8')),'Private machine path: '+file);}
const firmwareBins=[...files].filter(f=>f.startsWith('firmware/')&&f.endsWith('.bin'));assert.equal(firmwareBins.length,2);
const manifest={};for(const file of [...files].sort())manifest[file]=digest(stage+'/'+file);fs.writeFileSync(stage+'/SHA256SUMS.json',JSON.stringify(manifest,null,2)+'\n');
fs.mkdirSync(root+'/github-ready',{recursive:true});fs.writeFileSync(root+'/github-ready/LATEST.txt',path.relative(root,stage).replaceAll('\\','/')+'\n');
console.log('PASS: '+files.size+' upload files; exactly two firmware images; '+checkedLinks+' local links/anchors; matching source hashes; blank NVS; no expander assets or private paths.');
console.log('GitHub upload folder: '+stage);
