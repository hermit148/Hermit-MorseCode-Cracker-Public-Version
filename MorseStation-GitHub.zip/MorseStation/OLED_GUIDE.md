# HMC 3.3 / Simple OLED console

OLED_MENU_PLAN.md is the complete current hierarchy and keyboard plan.
The target remains SSD1306 **128x64**: 8,192 monochrome pixels and a 1,024-byte
framebuffer. Hardware colour comes from the panel. Wiring is unchanged:
3V3/GND, SDA GPIO5, SCL GPIO0; direct buttons GPIO3/4/7/10/1 to GND.

Home shows Send, Receive, Tools and Setup. Every submenu has Back. It restores
the previous menu and selection; Left/long Select are shortcuts outside Listen.
Listen keeps Select as the Morse key, so long dashes do not open a menu.

Text entry has a dedicated two-line preview above a 27-cell character area.
The six action buttons are case, numbers/symbols, delete, clear, send/save and
Back. Messages retain 120 characters. Credentials support lowercase and all
printable ASCII symbols, with field-specific bounds. Back preserves the message
and cancels unsaved credentials; Clear requires confirmation. Saved credentials
are masked and API responses omit them.

Setup > Connections includes router Wi-Fi, Telegram token/chat ID, and Discord
webhook URL. Configured/Partially configured/Not configured are shown explicitly;
these are saved-configuration states, not delivery/internet checks. Forwarding
has separate TX/RX toggles and defaults off.

Tools > System > Tests contains POST, Buzzer Test and Mic Test. The buzzer test
plays EE using the real-time engine. Boot plays the same short pattern when
Boot sound is on. Mic Test is Disabled in the direct-button/no-mic build. With
an enabled I2S mic it displays driver, input level and tone detection. No output
or driver-only check is presented as proof of physical hardware quality.

Startup uses a two-second nonblocking animation with a moving Send icon and
POST readiness stage. Input interrupts it. Normal pages stay stable, with no
automatic cycling. Boot is capped at 20 fps; normal display at 10 fps. Dimming
restores brightness on activity. Button/Morse tasks remain independent of I2C.

Wi-Fi scan/selection/password entry, link status and top-right router indicators
are described in WIFI_SETUP.md. Scan is asynchronous; Back stays visible.

The [screen gallery](docs/GALLERY.md) contains 48 exact
production-rendered frame examples. tests/test_oled.cpp executes the actual
renderer at compile time; tests/test_keyboard.cpp covers navigation, Back,
editing limits, case/symbol coverage, cancellation and secret-buffer handling.
Physical panel dimensions, controller, orientation, brightness and legibility
still need viewing on the module. An ACK cannot identify 128x32 versus 128x64.

Font attribution/license: OledFont.h and OLED_FONT_LICENSE.txt.
