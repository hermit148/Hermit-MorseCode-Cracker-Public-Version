#include "BuildConfig.h"
#include "DeviceIdentity.h"
#ifndef HMC_QA
#define HMC_QA 0
#endif
#if HMC_QA
void startTargetQa();
#endif
#include "MorseCore.h"
#include "SignalTools.h"
#include "OledUI.h"
#include "ButtonBoard.h"
#include "BleTools.h"
#include "TelegramCA.h"
#include "DiscordCA.h"
#include "NotificationCore.h"
#include "WebUI.h"
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Arduino.h>
#include <ArduinoJson.h>
#include <ESPmDNS.h>
#include <HTTPClient.h>
#include <Preferences.h>
#include <WebServer.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <Wire.h>
#include <atomic>
#include <esp_system.h>
#include <time.h>
#if ENABLE_I2S_MIC
#include <ESP_I2S.h>
I2SClass microphone;
#endif

// All realtime Morse state belongs to engineTask. Network I/O is isolated.
WebServer server(80);
Preferences prefs;
Adafruit_SSD1306 oled(128, 64, &Wire, -1, 400000, 400000);
bool oledOK = false;
uint8_t oledAddress = 0;
bool settingsOK = false, postApOK = false, engineOK = false, telegramOK = false;
uint32_t postStartedAt = 0;
bool postDisplayRequested = false;
SemaphoreHandle_t stateLock, configLock;
QueueHandle_t commands, events, telegramQueue;
std::atomic<bool> emergencyStop{false}, micTone{false}, micOK{false};
std::atomic<bool> playbackReserved{false};
std::atomic<bool> micFailed{false};
std::atomic<unsigned> micHz{700}, micDb{48};
std::atomic<float> micRms{0}, micRatio{0};
std::atomic<uint32_t> micUpdated{0}, eventDrops{0}, telegramDrops{0};
std::atomic<uint32_t> telegramGeneration{0};
std::atomic<uint32_t> discordGeneration{0},buzzerTests{0};
std::atomic<int> discordStatus{0};
std::atomic<bool> buzzerTesting{false};
std::atomic<int> telegramStatus{
    0}; // 0 idle,1 queued,2 delivered,3 retry,4 failed,5 no internet/time
struct Guard {
  SemaphoreHandle_t m;
  Guard(SemaphoreHandle_t s) : m(s) { xSemaphoreTake(m, portMAX_DELAY); }
  ~Guard() { xSemaphoreGive(m); }
};
struct Config {
  String ssid, pass, bot, chat,discordUrl;
  unsigned wpm = 12, hz = 700, db = 48;
  unsigned oledView = 0, oledContrast = 160;
  bool oledDim = true;
  bool forwardTx = false, forwardRx = false, autoWpm = false;
  bool discordTx=false,discordRx=false,bootSound=true;
};
Config cfg;
String deviceKey,
    apName; // Authentication uses a non-cookie header, not ambient browser credentials.
struct Command {
  uint8_t op = 0;
  uint8_t mode = 0;
  unsigned wpm = 12;
  char text[morse::MAX_TEXT + 1] = {};
};
enum : uint8_t { CMD_TX = 1, CMD_MODE = 2, CMD_FINISH = 3, CMD_CLEAR_RX = 4, CMD_CONVERT = 5, CMD_TRAIN = 6, CMD_BEEP = 7 };
enum : uint8_t { KEY_MODE = 0, MIC_MODE = 1 };
struct Event {
  char kind[12] = {};
  char text[morse::MAX_TEXT + 1] = {};
};
struct State {
  bool tx = false, key = false, tone = false;
  uint8_t mode = 0;
  char letter = 0;
  char text[121] = {}, pending[8] = {};
  unsigned wpm = 12, rxWpm = 12, txWpm = 12, speedSamples = 0;
  bool speedLocked = false, autoWpm = false;
};
State state;
morse::SignalTimeline signalTimeline;
struct Preset { String label, text; };
Preset presets[6];
hmcnav::Keyboard keyboard;
void serviceNavigation();
void keyboardGet();
void keyboardPost();
const char *FIRMWARE_VERSION = "HMC 3.3.0";
struct Log {
  uint32_t id = 0, ms = 0;
  Event event;
};
Log logs[24];
unsigned logCount = 0;
uint32_t nextId = 1;
struct TelegramJob {
  uint8_t provider=0;
  uint32_t id, generation;
  char kind[12];
  char text[121];
};
uint32_t reconnectAt = 0, lastOled = 0, bootAt = 0;
bool wifiWasConnected = false, paired = false;

void emit(const char *kind, const char *text) {
  Event e;
  strlcpy(e.kind, kind, sizeof(e.kind));
  strlcpy(e.text, text, sizeof(e.text));
  if (xQueueSend(events, &e, 0) != pdTRUE)
    eventDrops++;
}
void sound(bool on, unsigned hz) {
  static bool old = false;
  static unsigned oldHz = 0;
  if (on == old && (!on || hz == oldHz))
    return;
  old = on;
  oldHz = hz;
  if (on)
    tone(PIN_BUZZER, hz);
  else
    noTone(PIN_BUZZER);
}
void engineTask(void *) {
  morse::Receiver rx;
  static morse::Transmitter tx;
  unsigned speed = 12, receiveSpeed = 12, playbackWpm = 12;
  bool autoSpeed = false, training = false,testing=false;
  morse::SpeedEstimator estimator;
  estimator.reset(speed);
  auto resetRx = [&]() {
    rx.reset(receiveSpeed);
    if (autoSpeed && estimator.acquired()) rx.setUnit(estimator.unitMs());
  };
  resetRx();
  bool traceLevel = false, traceTx = false, traceValid = false;
  uint32_t traceStart = 0, pulseStart = 0;
  uint8_t mode = KEY_MODE;
  bool key = false;
  uint32_t lastSnapshot = 0, inhibitUntil = 0;
  bool input = false;
  char transmitted[121] = {};
  for (;;) {
    uint32_t now = millis();
    unsigned hz, wpm;
    bool autoEnabled;
    {
      Guard g(configLock);
      hz = cfg.hz;
      wpm = cfg.wpm;
      autoEnabled = cfg.autoWpm;
    }
    if ((wpm != speed || autoEnabled != autoSpeed) && !tx.active) {
      rx.finish();
      if (rx.ready)
        emit("RX", rx.text);
      speed = wpm;
      autoSpeed = autoEnabled;
      receiveSpeed = speed;
      estimator.reset(speed);
      resetRx();
      input = false;
    }
    key = hmcbuttons::morseEnabled.load() && (hmcbuttons::downMask.load() & 16);
    if (emergencyStop.exchange(false)) {
      xQueueReset(commands);
      if (tx.active)
        emit("CANCEL", transmitted);
      tx.stop();
          playbackReserved = false;
      buzzerTesting=false;
      resetRx();
      input = false;
    }
    Command cmd;
    if (xQueueReceive(commands, &cmd, 0) == pdTRUE) {
      if (cmd.op == CMD_TX || cmd.op == CMD_TRAIN || cmd.op==CMD_BEEP) {
        if (tx.active)
          emit("ERROR", "Transmitter busy; request rejected");
        else {
          rx.finish();
          if (rx.ready)
            emit("RX", rx.text);
          resetRx();
          input = false;
          strlcpy(transmitted, cmd.text, sizeof(transmitted));
          training = cmd.op == CMD_TRAIN;
          testing=cmd.op==CMD_BEEP;
          playbackWpm = training||testing ? cmd.wpm : speed;
          if (!tx.start(cmd.text, playbackWpm, now)) {
            playbackReserved = false;
            buzzerTesting=false;
            emit("ERROR", "Cannot start transmitter");
          }
        }
      } else if (cmd.op == CMD_MODE) {
        if (tx.active) {
          tx.stop();
          playbackReserved = false;
          emit("CANCEL", transmitted);
        }
        rx.finish();
        if (rx.ready)
          emit("RX", rx.text);
        mode = cmd.mode;
        estimator.reset(speed); receiveSpeed = speed;
        resetRx();
        input = false;
      } else if (cmd.op == CMD_FINISH) {
        rx.finish();
        if (rx.ready)
          emit("RX", rx.text);
        resetRx();
        input = false;
      } else if (cmd.op == CMD_CLEAR_RX) {
        resetRx();
        input = false;
      } else if (cmd.op == CMD_CONVERT)
        emit("DECODE", cmd.text);
    }
    if (tx.active) {
      if (tx.tick(now)) {
        playbackReserved = false;
        if(testing){++buzzerTests;buzzerTesting=false;}else emit(training ? "TRAIN" : "TX", transmitted);
        inhibitUntil = now + 250;
      }
      sound(tx.on, hz);

    } else {
      bool signal = mode == KEY_MODE ? key
                                     : (morse::due(now, inhibitUntil) && micOK.load() &&
                                        now - micUpdated.load() < 150 && micTone.load());
      if (signal != input) {
        input = signal;
        if (signal) pulseStart = now;
        else if (autoSpeed && estimator.observe(now - pulseStart)) {
          receiveSpeed = estimator.wpm();
          rx.setUnit(estimator.unitMs());
        }
        rx.edge(signal, now);
      }
      rx.tick(now);
      sound(mode == KEY_MODE && key, hz);

      if (rx.ready) {
        emit("RX", rx.text);
        resetRx();
        input = false;
      }
    }
    // Record completed edges, including TX, without browser polling jitter.
    bool traceNow = tx.active ? tx.on : input;
    bool sourceNow = tx.active;
    if (!traceValid || traceTx != sourceNow) {
      if (traceValid && traceLevel) {
        Guard g(stateLock); signalTimeline.add(traceStart, now - traceStart, traceLevel, traceTx);
      }
      traceValid = true; traceLevel = traceNow; traceTx = sourceNow; traceStart = now;
    } else if (traceNow != traceLevel) {
      uint32_t duration = now - traceStart;
      if (traceLevel || duration < 5000) {
        Guard g(stateLock); signalTimeline.add(traceStart, duration, traceLevel, traceTx);
      }
      traceStart = now; traceLevel = traceNow;
    }
    if (now - lastSnapshot >= 25) {
      lastSnapshot = now;
      Guard g(stateLock);
      state.tx = tx.active;
      state.key = input;
      state.tone = tx.active ? tx.on : input;
      state.mode = mode;
      state.letter = tx.active ? tx.letter : rx.lastChar;
      strlcpy(state.text, tx.active ? transmitted : rx.text, sizeof(state.text));
      strlcpy(state.pending, rx.pending(), sizeof(state.pending));
      state.wpm = speed;
      state.txWpm = playbackWpm;
      state.rxWpm = receiveSpeed;
      state.speedSamples = estimator.sampleCount();
      state.speedLocked = estimator.acquired();
      state.autoWpm = autoSpeed;
    }
    vTaskDelay(pdMS_TO_TICKS(1));
  }
}
#if ENABLE_I2S_MIC
void audioTask(void *) {
  microphone.setPins(PIN_MIC_BCLK, PIN_MIC_WS, -1, PIN_MIC_DATA);
  microphone.setTimeout(100);
  if (!microphone.begin(I2S_MODE_STD, 16000, I2S_DATA_BIT_WIDTH_32BIT, I2S_SLOT_MODE_MONO)) {
    micFailed = true;
    emit("ERROR", "I2S microphone initialization failed");
    vTaskDelete(nullptr);
    return;
  }
  micOK = true;
  int32_t samples[160];
  float data[160];
  bool gate = false, candidate = false;
  unsigned stable = 0;
  for (;;) {
    size_t bytes = microphone.readBytes((char *)samples, sizeof(samples));
    if (bytes != sizeof(samples)) {
      micTone = false;
      gate = false;
      vTaskDelay(1);
      continue;
    }
    for (unsigned i = 0; i < 160; i++)
      data[i] = float(samples[i] >> 8) / 8388608.f;
    auto r = morse::detectTone(data, 160, 16000, float(micHz.load()),
                               powf(10.f, -float(micDb.load()) / 20.f), gate);
    if (r.tone != candidate) {
      candidate = r.tone;
      stable = 1;
    } else
      ++stable;
    if (stable >= 2)
      gate = candidate;
    micTone = gate;
    micRms = r.rms;
    micRatio = r.ratio;
    micUpdated = millis();
  }
}
#endif

bool tokenValid(const String &s) {
  int colon = s.indexOf(':');
  if (colon < 5 || colon > 20 || s.length() < 30 || s.length() > 120)
    return false;
  for (int i = 0; i < colon; i++)
    if (!isDigit(s[i]))
      return false;
  for (unsigned i = colon + 1; i < s.length(); i++)
    if (!isalnum((unsigned char)s[i]) && s[i] != '_' && s[i] != '-')
      return false;
  return true;
}
bool chatValid(const String &s) {
  unsigned i = s.startsWith("-") ? 1 : 0;
  if (s.length() <= i || s.length() > 24)
    return false;
  for (; i < s.length(); i++)
    if (!isDigit(s[i]))
      return false;
  return true;
}
bool saveConfig(const Config &c) {
  JsonDocument d;
  d["ssid"] = c.ssid;
  d["pass"] = c.pass;
  d["bot"] = c.bot;
  d["chat"] = c.chat;
  d["wpm"] = c.wpm;
  d["hz"] = c.hz;
  d["db"] = c.db;
  d["forwardTx"] = c.forwardTx;
  d["forwardRx"] = c.forwardRx;
  d["autoWpm"] = c.autoWpm;
  d["oledView"] = c.oledView; d["oledContrast"] = c.oledContrast; d["oledDim"] = c.oledDim;
  d["discordUrl"]=c.discordUrl;d["discordTx"]=c.discordTx;d["discordRx"]=c.discordRx;d["bootSound"]=c.bootSound;
  String s;
  serializeJson(d, s);
  return prefs.putString("config", s) > 0;
}
void loadConfig() {
  settingsOK = prefs.begin("morse", false);
  deviceKey = HMC_AP_PASSWORD;
  if (prefs.getString("key", "") != deviceKey) {
    if (!prefs.putString("key", deviceKey)) settingsOK = false;
  }
  JsonDocument d;
  if (!deserializeJson(d, prefs.getString("config", "{}"))) {
    cfg.ssid = d["ssid"] | "";
    cfg.pass = d["pass"] | "";
    cfg.bot = d["bot"] | "";
    cfg.chat = d["chat"] | "";
    cfg.wpm = constrain(d["wpm"] | 12, 5, 30);
    cfg.hz = constrain(d["hz"] | 700, 400, 1200);
    cfg.db = constrain(d["db"] | 48, 15, 70);
    cfg.forwardTx = d["forwardTx"] | false;
    cfg.forwardRx = d["forwardRx"] | false;
    cfg.autoWpm = d["autoWpm"] | false;
    cfg.oledView = constrain(d["oledView"] | 0, 0, 7);
    cfg.oledContrast = constrain(d["oledContrast"] | 160, 16, 255);
    cfg.oledDim = d["oledDim"] | true;
    cfg.discordUrl=d["discordUrl"]|"";cfg.discordTx=d["discordTx"]|false;cfg.discordRx=d["discordRx"]|false;cfg.bootSound=d["bootSound"]|true;
  }
  JsonDocument savedPresets;
  if (!deserializeJson(savedPresets, prefs.getString("presets", "[]"))) {
    unsigned i = 0;
    for (JsonObject p : savedPresets.as<JsonArray>()) {
      if (i == 6) break;
      char normalized[121];
      String label = p["label"] | "", text = p["text"] | "";
      if (label.length() && label.length() <= 24 && morse::normalize(text.c_str(), normalized))
        presets[i] = {label, String(normalized)};
      ++i;
    }
  }
  micHz = cfg.hz;
  micDb = cfg.db;
}
#include "WifiManager.h"
// One worker serializes Telegram and Discord TLS sessions to bound RAM use.
class NotificationReply:public Stream{
public:String text;bool overflow=false;int available()override{return 0;}int read()override{return -1;}int peek()override{return -1;}void flush()override{}
 size_t write(uint8_t c)override{if(text.length()>=8192){overflow=true;return 0;}if(!text.concat(char(c))){overflow=true;return 0;}return 1;}
 size_t write(const uint8_t *p,size_t n)override{for(size_t i=0;i<n;++i)if(!write(p[i]))return i;return n;}
};
void telegramTask(void *) {
 TelegramJob job;
 for(;;){
  if(xQueueReceive(telegramQueue,&job,portMAX_DELAY)!=pdTRUE)continue;
  Config c;{Guard g(configLock);c=cfg;}
  bool dc=job.provider==1;auto &state=dc?discordStatus:telegramStatus;
  auto generation=[&](){return dc?discordGeneration.load():telegramGeneration.load();};
  if(job.generation!=generation())continue;
  if(dc?!hmcnotify::webhookValid(c.discordUrl.c_str()):(!tokenValid(c.bot)||!chatValid(c.chat))){state=4;continue;}
  char encoded[morse::MAX_CODE];if(!morse::encode(job.text,encoded,sizeof(encoded)))strlcpy(encoded,"Unavailable",sizeof(encoded));
  String msg="Hermit's Morse Cracker #"+String(job.id)+" ["+String(job.kind)+"]\nText: "+String(job.text)+"\nMorse: "+String(encoded);
  bool delivered=false;
  for(unsigned attempt=0;attempt<4;++attempt){
   if(job.generation!=generation())break;
   if(WiFi.status()!=WL_CONNECTED||time(nullptr)<1700000000){state=5;vTaskDelay(pdMS_TO_TICKS(5000));continue;}
   WiFiClientSecure client;client.setCACert(dc?DISCORD_CA:TELEGRAM_CA);client.setHandshakeTimeout(8);
   HTTPClient http;http.setConnectTimeout(5000);http.setTimeout(6000);http.setReuse(false);http.setFollowRedirects(HTTPC_DISABLE_FOLLOW_REDIRECTS);
   String url=dc?c.discordUrl+"?wait=true":"https://api.telegram.org/bot"+c.bot+"/sendMessage";
   if(!http.begin(client,url)){state=3;vTaskDelay(pdMS_TO_TICKS(2000));continue;}
   http.addHeader("Content-Type","application/json");JsonDocument body;
   if(dc){body["content"]=msg;body["allowed_mentions"]["parse"].to<JsonArray>();}
   else{body["chat_id"]=c.chat;body["text"]=msg;}
   String payload;serializeJson(body,payload);int code=http.POST(payload);
   JsonDocument reply;bool parsed=false;
   if(code>0){NotificationReply sink;int n=http.writeToStream(&sink);if(n>=0&&!sink.overflow)parsed=!deserializeJson(reply,sink.text);}
   http.end();
   if((dc&&(code==200||code==204))||(!dc&&code==200&&parsed&&reply["ok"].as<bool>())){delivered=true;state=2;break;}
   if(code>=400&&code<500&&code!=429){state=4;break;}
   unsigned waitMs=2000u<<attempt;
   if(code==429&&parsed){double sec=dc?(reply["retry_after"]|5.0):double(reply["parameters"]["retry_after"]|5u);if(sec>120||sec<0){state=4;break;}waitMs=unsigned(sec*1000)+100;}
   state=3;vTaskDelay(pdMS_TO_TICKS(waitMs));
  }
  if(!delivered&&job.generation==generation()&&state.load()!=5)state=4;
  vTaskDelay(pdMS_TO_TICKS(3100));
 }
}
void record(const Event &e) {
  unsigned slot = (nextId - 1) % 24;
  logs[slot] = {nextId++, millis(), e};
  if (logCount < 24)
    logCount++;
  Serial.printf("[%s] %s\n", e.kind, e.text);
  bool wanted[2]={};
  {Guard g(configLock);bool tx=!strcmp(e.kind,"TX"),rx=!strcmp(e.kind,"RX")||!strcmp(e.kind,"DECODE");wanted[0]=(tx&&cfg.forwardTx)||(rx&&cfg.forwardRx);wanted[1]=(tx&&cfg.discordTx)||(rx&&cfg.discordRx);}
  for(unsigned p=0;p<2;++p)if(wanted[p]){
    TelegramJob j;j.provider=p;j.generation=p?discordGeneration.load():telegramGeneration.load();j.id=logs[slot].id;strlcpy(j.kind,e.kind,sizeof(j.kind));strlcpy(j.text,e.text,sizeof(j.text));
    auto &state=p?discordStatus:telegramStatus;
    if(xQueueSend(telegramQueue,&j,0)==pdTRUE)state=1;else{++telegramDrops;state=4;}
  }
}

void securityHeaders() {
  server.sendHeader("Cache-Control", "no-store");
  server.sendHeader("X-Content-Type-Options", "nosniff");
  server.sendHeader("X-Frame-Options", "DENY");
  server.sendHeader("Referrer-Policy", "no-referrer");
}
class JsonResponseWriter : public Print {
  uint8_t buffer[512];size_t used=0;
public:
  size_t sent=0;bool failed=false;
  void flush(){
    size_t at=0;uint32_t progress=millis();
    while(at<used&&!failed){auto &client=server.client();if(!client.connected()){failed=true;break;}size_t n=client.write(buffer+at,used-at);if(n){at+=n;sent+=n;progress=millis();}else if(millis()-progress>5000){failed=true;client.stop();}else delay(1);}
    used=0;
  }
  size_t write(uint8_t c) override {if(failed)return 0;buffer[used++]=c;if(used==sizeof(buffer))flush();return failed?0:1;}
  size_t write(const uint8_t *data,size_t size) override {for(size_t i=0;i<size;++i)if(!write(data[i]))return i;return size;}
};
void jsonReply(int code, JsonDocument &d) {
  securityHeaders();
  if(d.overflowed()) {server.send_P(503,"application/json","{\"error\":\"Not enough memory for response; stop BLE and retry\"}");return;}
  server.setContentLength(measureJson(d));
  server.send(code,"application/json","");
  JsonResponseWriter writer;serializeJson(d,writer);writer.flush();
}
void fail(int code, const char *message) {
  JsonDocument d;
  d["error"] = message;
  jsonReply(code, d);
}
bool authorized() {
  String key = server.header("X-Device-Key");
  unsigned diff = key.length() ^ deviceKey.length();
  for (unsigned i = 0; i < deviceKey.length(); i++)
    diff |= (i < key.length() ? key[i] : 0) ^ deviceKey[i];
  if (diff) {
    fail(401, "Enter the device access key printed in Serial Monitor.");
    return false;
  }
  paired = true;
  return true;
}
bool readBody(JsonDocument &d) {
  if (!authorized())
    return false;
  if (server.header("Content-Type").indexOf("application/json") != 0) {
    fail(415, "JSON required");
    return false;
  }
  if (server.arg("plain").length() > 2048) {
    fail(413, "Request too large");
    return false;
  }
  if (deserializeJson(d, server.arg("plain"))) {
    fail(400, "Invalid JSON");
    return false;
  }
  if (!d.is<JsonObject>()) {
    fail(400, "JSON body must be an object");
    return false;
  }
  return true;
}
void accepted() {
  JsonDocument d;
  d["ok"] = true;
  jsonReply(202, d);
}
bool postCommand(Command &c) {
  bool playback = c.op == CMD_TX || c.op == CMD_TRAIN || c.op==CMD_BEEP;
  if (playback && playbackReserved.exchange(true)) {
    fail(409, "Playback is already running or queued");
    return false;
  }
  if (xQueueSend(commands, &c, 0) != pdTRUE) {
    if (playback) playbackReserved = false;
    fail(503, "Command queue full");
    return false;
  }
  if(c.op==CMD_BEEP)buzzerTesting=true;
  accepted();
  return true;
}
hmcpost::Report readPostReport() {
  using hmcpost::Status;
  hmcpost::Report report;
  report.items[hmcpost::Oled] = oledOK ? Status::Found : Status::Missing;
  report.items[hmcpost::Controller] = !hmcbuttons::taskOK?Status::Fail:hmcbuttons::ready?(BUTTONS_USE_MCP23017?Status::Found:Status::Pass):Status::Missing;
  for(unsigned i=0;i<5;++i) report.items[hmcpost::Up+i] = hmcbuttons::ready ? hmcpost::button(hmcbuttons::seenMask.load()&(1u<<i),hmcbuttons::downMask.load()&(1u<<i)) : Status::Check;
  // These output-only circuits have no return path to prove physical presence.
  report.items[hmcpost::Buzzer] = Status::Check;
  report.items[hmcpost::Mic] = hmcpost::microphone(ENABLE_I2S_MIC,micOK.load(),micFailed.load());
  report.items[hmcpost::Flash] = ESP.getFlashChipSize() >= 4194304 ? Status::Pass : Status::Fail;
  report.items[hmcpost::Nvs] = settingsOK ? Status::Pass : Status::Fail;
  report.items[hmcpost::Ram] = stateLock && configLock && commands && events && telegramQueue && hmcbuttons::queue && hmcbuttons::taskOK && ESP.getFreeHeap()>16384 ? Status::Pass : Status::Fail;
  report.items[hmcpost::Wifi] = postApOK ? Status::Pass : Status::Fail;
  return report;
}
void printPostReport() {
  const auto report = readPostReport();
  Serial.printf("\n=== %s POWER-ON SELF-TEST ===\n",FIRMWARE_VERSION);
  for(unsigned i=0;i<hmcpost::Count;++i)
    Serial.printf("[POST] %-9s : %s\n",hmcpost::name(i),hmcpost::label(report.items[i]));
  if(oledOK) Serial.printf("[POST] OLED ACK at 0x%02X; controller/pixels still require visual check\n",oledAddress);
  else Serial.printf("[POST] OLED missing: SDA GPIO%d / SCL GPIO%d; retrying 0x3C/0x3D every 5s\n",PIN_SDA,PIN_SCL);
#if BUTTONS_USE_MCP23017
  Serial.printf("[POST] MCP23017 at 0x%02X: GPA0 UP, GPA1 DOWN, GPA2 LEFT, GPA3 RIGHT, GPA4 SELECT\n",NAV_I2C_ADDRESS);
#else
  Serial.printf("[POST] Direct buttons to GND: UP GPIO%d, DOWN GPIO%d, LEFT GPIO%d, RIGHT GPIO%d, SELECT GPIO%d\n",NAV_BUTTON_PINS[0],NAV_BUTTON_PINS[1],NAV_BUTTON_PINS[2],NAV_BUTTON_PINS[3],NAV_BUTTON_PINS[4]);
  Serial.println("[POST] BUTTONS PASS means pullup inputs initialized; press/release every switch to verify");
#endif
  Serial.println("[POST] Buttons: press AND release to mark SEEN; LED bank removed");
  Serial.printf("[POST] BUZZER GPIO%d: no electrical feedback; verify by listening during playback\n",PIN_BUZZER);
  Serial.println("[POST] MIC OFF = disabled build; DRIVER = I2S initialized, physical microphone unverified");
#if ENABLE_I2S_MIC
  Serial.printf("[POST] INMP441: SCK GPIO%d, WS GPIO%d, SD GPIO%d; L/R to GND\n",PIN_MIC_BCLK,PIN_MIC_WS,PIN_MIC_DATA);
#if MIC_DIRECT_BOOT_CLOCK
  Serial.println("[POST] Direct mic: GPIO2 requires external 10k pullup to 3V3 for reset/boot");
#endif
#endif
  Serial.printf("[POST] FLASH %lu bytes / free RAM %lu bytes / Morse task %s / Telegram task %s\n",
                (unsigned long)ESP.getFlashChipSize(),(unsigned long)ESP.getFreeHeap(),engineOK?"PASS":"FAIL",telegramOK?"PASS":"FAIL");
  Serial.printf("[POST] %u missing/failed; CHECK means manual verification, not missing\n",hmcpost::missing(report));
  Serial.println("[POST] Type POST + Enter to repeat and show report on OLED. Serial: 115200 baud.\n");
}
void servicePost(uint32_t now) {
  // Bounded, non-blocking serial command reader; no readString timeout stalls.
  static char line[16] = {};
  static unsigned used = 0;
  static bool overflow = false;
  for(unsigned budget=0;budget<32 && Serial.available();++budget) {
    char c=Serial.read();
    if(c=='\r'||c=='\n') {
      if(used && !overflow) {
        line[used]=0;
        if(!strcmp(line,"POST")) { printPostReport(); keyboard.go(hmcnav::Screen::Post); keyboard.active=true; keyboard.changedAt=now; }
        else if(!strcmp(line,"HOME")){keyboard.go(hmcnav::Screen::Menu);keyboard.active=true;keyboard.changedAt=now;Serial.println("[UI] Home: SEND / RECEIVE / TOOLS / SETUP");}
#if HMC_QA
        else if(!strcmp(line,"QA")) startTargetQa();
#endif
        else if(!strcmp(line,"NET"))printNetworkReport();
        else if(!strcmp(line,"WIFISCAN")){int rc=startWifiScan();Serial.printf("[WIFI SCAN] %s (%d)\n",rc?"NOT STARTED":"STARTED",rc);}
        else if(!strcmp(line,"HELP")) Serial.println("Commands: POST, HOME, NET (connection diagnostics), WIFISCAN, HELP. Newline enabled; 115200 baud.");
        else Serial.println("Unknown command. Type POST or HELP.");
      } else if(overflow) Serial.println("Command too long; type POST or HELP.");
      used=0; overflow=false;
    } else if(used<sizeof(line)-1) {
      line[used++]=morse::upper(c);
    } else overflow=true;
  }
  static uint32_t checkedAt=0;
  static hmcpost::Report previous;
  static bool initial=true;
  if(now-checkedAt<500)return;
  checkedAt=now;
  const auto report=readPostReport();
  if(!initial)for(unsigned i=0;i<hmcpost::Count;++i)if(previous.items[i]!=report.items[i])
    Serial.printf("[POST UPDATE] %-9s : %s\n",hmcpost::name(i),hmcpost::label(report.items[i]));
  previous=report;initial=false;
}
void statusRoute() {
  if (!authorized())
    return;
  State s;
  {
    Guard g(stateLock);
    s = state;
  }
  JsonDocument d;
  d["tx"] = s.tx;
  d["mode"] = s.mode == KEY_MODE ? "key" : "mic";
  d["key"] = s.key;
  d["tone"] = s.tone;
  d["letter"] = String(s.letter ? s.letter : ' ');
  d["text"] = s.text;
  d["pending"] = s.pending;
  d["wpm"] = s.wpm;
  d["txWpm"] = s.txWpm;
  d["rxWpm"] = s.rxWpm; d["speedLocked"] = s.speedLocked; d["speedSamples"] = s.speedSamples;
  d["autoWpm"] = s.autoWpm;
  d["firmware"] = FIRMWARE_VERSION;
  d["heap"] = ESP.getFreeHeap(); d["minHeap"] = ESP.getMinFreeHeap();
  d["heapBlock"] = ESP.getMaxAllocHeap();
  d["cpuMHz"] = ESP.getCpuFreqMHz(); d["flashBytes"] = ESP.getFlashChipSize();
  d["appBytes"] = ESP.getSketchSize(); d["resetReason"] = int(esp_reset_reason());
  d["apClients"] = WiFi.softAPgetStationNum(); d["oled"] = oledOK;
  const auto post = readPostReport();
  auto hardware = d["post"].to<JsonObject>();
  for(unsigned i=0;i<hmcpost::Count;++i) hardware[hmcpost::name(i)] = hmcpost::label(post.items[i]);
  d["ip"] = WiFi.status() == WL_CONNECTED ? WiFi.localIP().toString() : WiFi.softAPIP().toString();
  d["online"] = wifiConnected();wifiSummary(d["wifi"].to<JsonObject>());
  d["rssi"] = WiFi.status() == WL_CONNECTED ? WiFi.RSSI() : 0;
  d["micAvailable"] = bool(ENABLE_I2S_MIC);
  d["micReady"] = micOK.load();
  d["rms"] = micRms.load();
  d["ratio"] = micRatio.load();
  d["signal"] = micTone.load();
  d["telegram"] = telegramStatus.load();
  d["discord"]=discordStatus.load();d["buzzerTesting"]=buzzerTesting.load();d["buzzerTests"]=buzzerTests.load();
  d["queue"] = uxQueueMessagesWaiting(telegramQueue);
  d["dropped"] = eventDrops.load() + telegramDrops.load() + hmcbuttons::drops.load();
  d["buttonController"] = hmcbuttons::ready.load();
  d["buttonWiring"] = hmcbuttons::wiring();
  d["uptime"] = millis() / 1000;
  // History is immutable while this main-loop handler runs. Measure and send
  // one record at a time instead of allocating a 25 KB document with BLE active.
  uint32_t first=nextId-logCount;
  auto historyRecord=[&](JsonDocument &entry,uint32_t id){const Log &l=logs[(id-1)%24];entry["id"]=l.id;entry["ms"]=l.ms;entry["kind"]=l.event.kind;entry["text"]=l.event.text;char code[morse::MAX_CODE];if(morse::encode(l.event.text,code,sizeof(code)))entry["morse"]=code;};
  if(d.overflowed()){fail(503,"Not enough memory for status; stop BLE and retry");return;}
  String metadata;size_t base=measureJson(d);if(!metadata.reserve(base)){fail(503,"Not enough memory for status; stop BLE and retry");return;}serializeJson(d,metadata);metadata.remove(metadata.length()-1);
  size_t total=metadata.length()+strlen(",\"logs\":[")+2;
  for(uint32_t id=first;id<nextId;++id){JsonDocument entry;historyRecord(entry,id);if(entry.overflowed()){fail(503,"Not enough memory for history; retry");return;}total+=measureJson(entry)+(id!=first);}
  securityHeaders();server.setContentLength(total);server.send(200,"application/json","");
  JsonResponseWriter writer;writer.write(reinterpret_cast<const uint8_t*>(metadata.c_str()),metadata.length());writer.write(reinterpret_cast<const uint8_t*>(",\"logs\":["),9);
  for(uint32_t id=first;id<nextId&&server.client().connected()&&!writer.failed;++id){if(id!=first)writer.write(uint8_t(','));JsonDocument entry;historyRecord(entry,id);if(entry.overflowed()){server.client().stop();return;}serializeJson(entry,writer);delay(1);}
  writer.write(reinterpret_cast<const uint8_t*>("]}"),2);writer.flush();
#if HMC_QA
  if(writer.failed||writer.sent!=total)Serial.printf("[QA STREAM] sent %u expected %u failed %u heap %lu\n",unsigned(writer.sent),unsigned(total),writer.failed,(unsigned long)ESP.getFreeHeap());
#endif
}

void configGet() {
  if (!authorized())
    return;
  Config c;
  {
    Guard g(configLock);
    c = cfg;
  }
  JsonDocument d;
  d["ssid"] = c.ssid;
  d["chat"] = c.chat;
  d["botSet"] = c.bot.length() > 0;
  d["telegramConfigured"]=tokenValid(c.bot)&&chatValid(c.chat);d["discordConfigured"]=hmcnotify::webhookValid(c.discordUrl.c_str());d["discordSet"]=c.discordUrl.length()>0;
  d["wifiSet"] = c.pass.length() > 0;
  d["wpm"] = c.wpm;
  d["hz"] = c.hz;
  d["db"] = c.db;
  d["forwardTx"] = c.forwardTx;
  d["forwardRx"] = c.forwardRx;
  d["autoWpm"] = c.autoWpm;
  d["oledView"] = c.oledView; d["oledContrast"] = c.oledContrast; d["oledDim"] = c.oledDim;
  d["discordTx"]=c.discordTx;d["discordRx"]=c.discordRx;d["bootSound"]=c.bootSound;
  jsonReply(200, d);
}
void configPost() {
  JsonDocument d;
  if (!readBody(d))
    return;
  for (const char *field : {"wpm", "hz", "db", "oledView", "oledContrast"})
    if (!d[field].isNull() && !d[field].is<unsigned>()) {
      fail(400, "Timing fields must be positive integers");
      return;
    }
  for (const char *field : {"ssid", "pass", "bot", "chat", "discordUrl"})
    if (!d[field].isNull() && !d[field].is<const char *>()) {
      fail(400, "Credential fields must be strings");
      return;
    }
  for (const char *field : {"openWifi", "clearTelegram", "forwardTx", "forwardRx", "autoWpm", "oledDim", "discordTx", "discordRx", "clearDiscord", "bootSound"})
    if (!d[field].isNull() && !d[field].is<bool>()) {
      fail(400, "Flags must be booleans");
      return;
    }
  Config c;
  {
    Guard g(configLock);
    c = cfg;
  }
  if (d["wpm"].is<unsigned>())
    c.wpm = d["wpm"];
  if (d["hz"].is<unsigned>())
    c.hz = d["hz"];
  if (d["db"].is<unsigned>())
    c.db = d["db"];
  if (d["autoWpm"].is<bool>()) c.autoWpm = d["autoWpm"];
  if (d["oledView"].is<unsigned>()) c.oledView = d["oledView"];
  if (d["oledContrast"].is<unsigned>()) c.oledContrast = d["oledContrast"];
  if (d["oledDim"].is<bool>()) c.oledDim = d["oledDim"];
  if(d["bootSound"].is<bool>())c.bootSound=d["bootSound"];
  if(d["discordTx"].is<bool>())c.discordTx=d["discordTx"];if(d["discordRx"].is<bool>())c.discordRx=d["discordRx"];
  if(d["discordUrl"].is<const char*>()&&d["discordUrl"].as<String>().length())c.discordUrl=d["discordUrl"].as<String>();
  if(d["clearDiscord"]==true){c.discordUrl="";c.discordTx=c.discordRx=false;}
  if((c.discordUrl.length()&&!hmcnotify::webhookValid(c.discordUrl.c_str()))||((c.discordTx||c.discordRx)&&!hmcnotify::webhookValid(c.discordUrl.c_str()))){fail(400,"Supply a valid discord.com webhook URL");return;}
  if (c.oledView > 7 || c.oledContrast < 16 || c.oledContrast > 255) {
    fail(400, "OLED page must be 0-7 and brightness 16-255"); return;
  }
  if (c.wpm < 5 || c.wpm > 30 || c.hz < 400 || c.hz > 1200 || c.db < 15 || c.db > 70) {
    fail(400, "Invalid speed, frequency or threshold");
    return;
  }
  if (d["ssid"].is<const char *>()){if(c.ssid!=d["ssid"].as<String>())c.pass="";c.ssid = d["ssid"].as<String>();}
  if (d["pass"].is<const char *>() && d["pass"].as<String>().length())
    c.pass = d["pass"].as<String>();
  if (d["openWifi"] == true)
    c.pass = "";
  if (d["bot"].is<const char *>() && d["bot"].as<String>().length())
    c.bot = d["bot"].as<String>();
  if (d["chat"].is<const char *>())
    c.chat = d["chat"].as<String>();
  if (d["clearTelegram"] == true) {
    c.bot = "";
    c.chat = "";
    c.forwardTx = c.forwardRx = false;
  } else {
    if (d["forwardTx"].is<bool>())
      c.forwardTx = d["forwardTx"];
    if (d["forwardRx"].is<bool>())
      c.forwardRx = d["forwardRx"];
  }
  if (c.ssid.length() > 32 || c.pass.length() > 63 ||
      (c.pass.length() > 0 && c.pass.length() < 8)) {
    fail(400, "Wi-Fi SSID or password length is invalid");
    return;
  }
  if ((c.bot.length() && !tokenValid(c.bot)) || (c.chat.length() && !chatValid(c.chat)) ||
      ((c.forwardTx || c.forwardRx) && (!tokenValid(c.bot) || !chatValid(c.chat)))) {
    fail(400, "Supply a valid bot token and numeric chat ID");
    return;
  }
  if (!saveConfig(c)) {
    fail(500, "Could not save settings; previous configuration remains active");
    return;
  }
  bool wifiChanged;
  {
    Guard g(configLock);
    wifiChanged = cfg.ssid != c.ssid || cfg.pass != c.pass;
    if (cfg.bot != c.bot || cfg.chat != c.chat || cfg.forwardTx != c.forwardTx ||
        cfg.forwardRx != c.forwardRx || cfg.discordUrl!=c.discordUrl || cfg.discordTx!=c.discordTx || cfg.discordRx!=c.discordRx) {
      telegramGeneration++;
      discordGeneration++;discordStatus=0;
      xQueueReset(telegramQueue);
      telegramStatus = 0;
    }
    bool viewChanged=cfg.oledView!=c.oledView;
    cfg = c;
    if(viewChanged){keyboard.go(hmcnav::viewScreen(c.oledView));keyboard.active=true;keyboard.changedAt=millis();}
  }
  micHz = c.hz;
  micDb = c.db;
  accepted();
  if (wifiChanged) requestWifiConnection();
}
bool commitWifi(const String &ssid,const String &pass){
 Config c;{Guard g(configLock);c=cfg;}c.ssid=ssid;c.pass=pass;
 if(!saveConfig(c))return false;
 {Guard g(configLock);cfg=c;}requestWifiConnection();return true;
}
void wifiGet(){
 if(!authorized())return;JsonDocument d;wifiSummary(d["wifi"].to<JsonObject>());
 d["status"]=wifiScanning?"scanning":wifiScanFailed?"failed":wifiScanDone?"ready":"idle";
 d["scannedAt"]=wifiScannedAt;auto a=d["networks"].to<JsonArray>();
 for(unsigned i=0;i<wifiNetworks.count;++i){const auto &n=wifiNetworks.items[i];auto o=a.add<JsonObject>();o["ssid"]=n.ssid;o["rssi"]=n.rssi;o["channel"]=n.channel;o["secure"]=n.secure;o["supported"]=n.supported;}
 jsonReply(200,d);
}
void wifiPost(){
 JsonDocument d;if(!readBody(d))return;
 if(!d["op"].is<const char*>()){fail(400,"Wi-Fi operation must be a string");return;}String op=d["op"].as<String>();
 if(op=="scan"){int rc=startWifiScan();if(rc==-1)fail(409,"Wi-Fi scan already running");else if(rc==-2)fail(429,"Wait 10 seconds between Wi-Fi scans");else if(rc)fail(503,"Wi-Fi scan could not start; retry shortly");else accepted();return;}
 if(op!="connect"){fail(400,"Unknown Wi-Fi operation");return;}
 if(!d["ssid"].is<const char*>()||(!d["pass"].isNull()&&!d["pass"].is<const char*>())||(!d["open"].isNull()&&!d["open"].is<bool>())||(!d["useSavedPassword"].isNull()&&!d["useSavedPassword"].is<bool>())){fail(400,"Invalid Wi-Fi connection fields");return;}
 String ssid=d["ssid"].as<String>(),pass=d["pass"]|"";
 if(!ssid.length()||ssid.length()>32||ssid==HMC_AP_NAME||pass.length()>63){fail(400,"Choose a router SSID (1-32 bytes) and a valid password");return;}
 for(unsigned i=0;i<ssid.length();++i)if(uint8_t(ssid[i])<32||uint8_t(ssid[i])==127){fail(400,"SSID contains unsupported control characters");return;}
 bool known=false,secure=true,supported=true;
 for(unsigned i=0;i<wifiNetworks.count;++i)if(ssid==wifiNetworks.items[i].ssid){known=true;secure=wifiNetworks.items[i].secure;supported=wifiNetworks.items[i].supported;break;}
 if(!supported){fail(400,"This network requires an unsupported sign-in method. Use a personal WPA2/WPA3 network.");return;}
 if(d["useSavedPassword"]==true){Guard g(configLock);if(ssid!=cfg.ssid||!cfg.pass.length()){fail(400,"No password is saved for this network");return;}pass=cfg.pass;}
 bool open=d["open"]==true;if(known&&!secure)open=true;
 if(open&&known&&secure){fail(400,"This network requires a password");return;}
 if(open)pass="";else if(pass.length()<8){fail(400,"Enter the network password (8-63 characters), or select an open network");return;}
 if(!commitWifi(ssid,pass)){fail(500,"Could not save Wi-Fi settings");return;}accepted();
}
void timelineRoute() {
  if (!authorized()) return;
  morse::SignalTimeline snapshot;
  { Guard g(stateLock); snapshot = signalTimeline; }
  JsonDocument d;
  d["next"] = snapshot.next;
  auto arr = d["segments"].to<JsonArray>();
  uint32_t first = snapshot.next - snapshot.count;
  for (uint32_t id = first; id < snapshot.next; ++id) {
    const auto &s = snapshot.items[(id - 1) % snapshot.capacity];
    auto row = arr.add<JsonArray>();
    row.add(s.id); row.add(s.at); row.add(s.duration); row.add(s.on); row.add(s.tx);
  }
  jsonReply(200, d);
}
void presetsGet() {
  if (!authorized()) return;
  JsonDocument d; auto list = d["presets"].to<JsonArray>();
  for (const auto &p : presets) {
    auto item = list.add<JsonObject>(); item["label"] = p.label; item["text"] = p.text;
  }
  jsonReply(200, d);
}
void presetsPost() {
  JsonDocument d; if (!readBody(d)) return;
  if (!d["presets"].is<JsonArray>() || d["presets"].size() != 6) {
    fail(400, "Supply exactly six preset slots"); return;
  }
  Preset proposed[6]; unsigned i = 0;
  for (JsonVariant p : d["presets"].as<JsonArray>()) {
    if (!p["label"].is<const char *>() || !p["text"].is<const char *>()) {
      fail(400, "Preset label and text must be strings"); return;
    }
    String label = p["label"].as<String>(), text = p["text"].as<String>();
    if (label.length() > 24 || text.length() > 120 || bool(label.length()) != bool(text.length())) {
      fail(400, "Use a label (1-24) and message (1-120), or clear both"); return;
    }
    for (unsigned j = 0; j < label.length(); ++j) if ((uint8_t)label[j] < 32 || (uint8_t)label[j] > 126) {
      fail(400, "Use printable ASCII preset labels"); return;
    }
    char normalized[121] = {};
    if (text.length() && !morse::normalize(text.c_str(), normalized)) {
      fail(400, "Unsupported Morse message"); return;
    }
    proposed[i++] = {label, String(normalized)};
  }
  JsonDocument saved; auto list = saved.to<JsonArray>();
  for (const auto &p : proposed) { auto item = list.add<JsonObject>(); item["label"] = p.label; item["text"] = p.text; }
  String serialized; serializeJson(saved, serialized);
  if (!prefs.putString("presets", serialized)) { fail(500, "Could not save presets"); return; }
  for (unsigned j = 0; j < 6; ++j) presets[j] = proposed[j];
  accepted();
}
void blePost() {
  JsonDocument d; if (!readBody(d)) return;
  String op = d["op"] | "";
  if (op == "stop") { bletools::stop(); accepted(); return; }
  if (op != "scan" && op != "beacon") { fail(400, "Unknown BLE operation"); return; }
  String name = d["name"] | "HMC-BEACON";
  if (op == "beacon") {
    if (name.length() < 1 || name.length() > 20) { fail(400, "Beacon name: 1-20 ASCII characters"); return; }
    for (unsigned i = 0; i < name.length(); ++i) if ((uint8_t)name[i] < 32 || (uint8_t)name[i] > 126) {
      fail(400, "Use a printable ASCII beacon name"); return;
    }
  }
  int rc = op == "scan" ? bletools::scan() : bletools::advertise(name.c_str());
  if (rc == -2) { fail(503, "BLE starting or unavailable; check status and retry"); return; }
  if (rc == -3) { fail(409, "Stop the current BLE operation first"); return; }
  if (rc == -4) { fail(429, "Wait 10 seconds between scan starts"); return; }
  if (rc) { fail(503, "BLE operation failed; see BLE error code"); return; }
  accepted();
}
void setupWeb() {
  const char *headers[] = {"X-Device-Key", "Content-Type"};
  server.collectHeaders(headers, 2);
  server.on("/", HTTP_GET, [] {
    securityHeaders();
    constexpr size_t length=sizeof(WEB_UI)-1;
    server.setContentLength(length);server.send(200,"text/html","");
    for(size_t offset=0;offset<length&&server.client().connected();offset+=1024)
      server.sendContent_P(WEB_UI+offset,length-offset>1024?1024:length-offset);
  });
  server.on("/api/status", HTTP_GET, statusRoute);
  server.on("/api/wifi",HTTP_GET,wifiGet);server.on("/api/wifi",HTTP_POST,wifiPost);
  server.on("/api/keyboard",HTTP_GET,keyboardGet);
  server.on("/api/keyboard",HTTP_POST,keyboardPost);
  server.on("/api/buzzer-test",HTTP_POST,[]{JsonDocument d;if(!readBody(d))return;Command c;c.op=CMD_BEEP;c.wpm=20;strlcpy(c.text,"EE",sizeof(c.text));postCommand(c);});
  server.on("/api/timeline", HTTP_GET, timelineRoute);
  server.on("/api/presets", HTTP_GET, presetsGet);
  server.on("/api/presets", HTTP_POST, presetsPost);
  server.on("/api/ble", HTTP_GET, [] { if (!authorized()) return; JsonDocument d; bletools::status(d); jsonReply(200, d); });
  server.on("/api/ble", HTTP_POST, blePost);
  server.on("/api/train", HTTP_POST, [] {
    JsonDocument d; if (!readBody(d)) return;
    if (!d["text"].is<const char *>() || !d["wpm"].is<unsigned>()) { fail(400, "Training needs text and integer WPM"); return; }
    Command c; c.op = CMD_TRAIN; c.wpm = d["wpm"];
    if (c.wpm < 5 || c.wpm > 30 || !morse::normalize(d["text"], c.text) || strlen(c.text) > 20) {
      fail(400, "Training: 1-20 Morse characters, 5-30 WPM"); return;
    }
    bool busy;
    { Guard g(stateLock); busy = state.tx; }
    if (busy) { fail(409, "Playback is already running"); return; }
    postCommand(c);
  });
  server.on("/api/config", HTTP_GET, configGet);
  server.on("/api/config", HTTP_POST, configPost);
  server.on("/api/transmit", HTTP_POST, [] {
    JsonDocument d;
    if (!readBody(d))
      return;
    Command c;
    c.op = CMD_TX;
    const char *input = d["text"] | "";
    if (strlen(input) > 600 || !morse::normalize(input, c.text)) {
      fail(400, "Use supported Morse characters; maximum 120 characters");
      return;
    }
    bool busy;
    {
      Guard g(stateLock);
      busy = state.tx;
    }
    if (busy) {
      fail(409, "Playback is already running");
      return;
    }
    postCommand(c);
  });
  server.on("/api/decode", HTTP_POST, [] {
    JsonDocument d;
    if (!readBody(d))
      return;
    Command c;
    c.op = CMD_CONVERT;
    if (!morse::decodeText(d["morse"] | "", c.text)) {
      fail(400, "Invalid Morse. Separate letters with spaces and words with /.");
      return;
    }
    postCommand(c);
  });
  server.on("/api/mode", HTTP_POST, [] {
    JsonDocument d;
    if (!readBody(d))
      return;
    String mode = d["mode"] | "";
    if (mode != "key" && mode != "mic") {
      fail(400, "Unknown mode");
      return;
    }
    if (mode == "mic" && !ENABLE_I2S_MIC) {
      fail(409, "Wire INMP441 and enable ENABLE_I2S_MIC in BuildConfig.h");
      return;
    }
    Command c;
    c.op = CMD_MODE;
    c.mode = mode == "mic" ? MIC_MODE : KEY_MODE;
    postCommand(c);
  });
  server.on("/api/stop", HTTP_POST, [] {
    JsonDocument d;
    if (!readBody(d))
      return;
    emergencyStop = true;
    accepted();
  });
  server.on("/api/finish", HTTP_POST, [] {
    JsonDocument d;
    if (!readBody(d))
      return;
    Command c;
    c.op = CMD_FINISH;
    postCommand(c);
  });
  server.on("/api/clear", HTTP_POST, [] {
    JsonDocument d;
    if (!readBody(d))
      return;
    Command c;
    c.op = CMD_CLEAR_RX;
    postCommand(c);
  });
  server.on("/api/telegram-test", HTTP_POST, [] {
    JsonDocument d;
    if (!readBody(d))
      return;
    bool valid;
    {
      Guard g(configLock);
      valid = tokenValid(cfg.bot) && chatValid(cfg.chat);
    }
    if (!valid) {
      fail(400, "Save a bot token and chat ID first");
      return;
    }
    if(!wifiConnected()){fail(503,"Wi-Fi is not connected. Select a network and connect in Wi-Fi settings first.");return;}
    if(time(nullptr)<1700000000){fail(503,"Wi-Fi connected; waiting for clock synchronization. Retry shortly.");return;}
    TelegramJob j{};
    j.generation = telegramGeneration.load();
    j.id = nextId;
    strlcpy(j.kind, "TEST", sizeof(j.kind));
    strlcpy(j.text, "MORSE STATION CONNECTED", sizeof(j.text));
    if (xQueueSend(telegramQueue, &j, 0) != pdTRUE) {
      fail(503, "Telegram queue full");
      return;
    }
    telegramStatus = 1;
    accepted();
  });
  server.onNotFound([] { fail(404, "Not found"); });
  server.begin();
}
bool localCommand(Command &command) {
  bool playback=command.op==CMD_TX||command.op==CMD_BEEP;
  if(playback&&playbackReserved.exchange(true)){keyboard.notice=hmcnav::Notice::Busy;return false;}
  if(xQueueSend(commands,&command,0)!=pdTRUE){if(playback)playbackReserved=false;keyboard.notice=hmcnav::Notice::Busy;return false;}
  return true;
}
hmcnav::Action pendingLocalBle=hmcnav::Action::None;
uint32_t localBleAt=0,localBleTry=0;
bool saveLocalConfig(const Config &c){
  if((c.bot.length()&&!tokenValid(c.bot))||(c.chat.length()&&!chatValid(c.chat))||((c.forwardTx||c.forwardRx)&&(!tokenValid(c.bot)||!chatValid(c.chat)))||(c.discordUrl.length()&&!hmcnotify::webhookValid(c.discordUrl.c_str()))||((c.discordTx||c.discordRx)&&!hmcnotify::webhookValid(c.discordUrl.c_str()))||c.ssid.length()>32||c.pass.length()>63||(c.pass.length()>0&&c.pass.length()<8)){keyboard.notice=hmcnav::Notice::Invalid;return false;}
  if(!saveConfig(c)){keyboard.notice=hmcnav::Notice::Failed;return false;}
  bool wifiChanged=false;
  {Guard g(configLock);wifiChanged=cfg.ssid!=c.ssid||cfg.pass!=c.pass;
    if(cfg.bot!=c.bot||cfg.chat!=c.chat||cfg.forwardTx!=c.forwardTx||cfg.forwardRx!=c.forwardRx||cfg.discordUrl!=c.discordUrl||cfg.discordTx!=c.discordTx||cfg.discordRx!=c.discordRx){++telegramGeneration;++discordGeneration;xQueueReset(telegramQueue);telegramStatus=discordStatus=0;}
    cfg=c;}
  micHz=c.hz;micDb=c.db;
  if(wifiChanged)requestWifiConnection();return true;
}
void applyKeyboardAction(hmcnav::Action action) {
  using hmcnav::Action;using hmcnav::Notice;
  if(action==Action::None)return;
  if(action==Action::WifiScan){int rc=startWifiScan();keyboard.notice=rc==-2?Notice::Cooldown:rc==-1?Notice::Busy:rc?Notice::Failed:Notice::Ready;return;}
  if(action==Action::WifiRetry){requestWifiConnection();keyboard.notice=Notice::Ready;return;}
  if(action==Action::WifiChoose){
    if(wifiScanning||keyboard.menu>=wifiNetworks.count){keyboard.notice=Notice::Busy;return;}
    const auto &n=wifiNetworks.items[keyboard.menu];
    if(!n.supported){keyboard.notice=Notice::Unavailable;return;}
    if(!n.secure){if(commitWifi(n.ssid,"")){keyboard.open(hmcnav::Screen::WifiStatus);keyboard.notice=Notice::Ready;}else keyboard.notice=Notice::Failed;return;}
    Config c;{Guard g(configLock);c=cfg;}wifiDraftSsid=n.ssid;wifiDraftActive=true;
    keyboard.beginEntry(hmcnav::Field::WifiPass,c.ssid==wifiDraftSsid?c.pass.c_str():"");return;
  }
  Command command;
  if(action==Action::TestBuzzer){command.op=CMD_BEEP;command.wpm=20;strlcpy(command.text,"EE",sizeof(command.text));if(localCommand(command)){buzzerTesting=true;keyboard.notice=Notice::Ready;}return;}
  if(action==Action::EditWifiSsid||action==Action::EditWifiPass||action==Action::EditTgToken||action==Action::EditTgChat||action==Action::EditDiscord){
    Config c;{Guard g(configLock);c=cfg;}using hmcnav::Field;
    auto field=action==Action::EditWifiSsid?Field::WifiSsid:action==Action::EditWifiPass?Field::WifiPass:action==Action::EditTgToken?Field::TgToken:action==Action::EditTgChat?Field::TgChat:Field::DiscordUrl;
    const String &value=action==Action::EditWifiSsid?c.ssid:action==Action::EditWifiPass?c.pass:action==Action::EditTgToken?c.bot:action==Action::EditTgChat?c.chat:c.discordUrl;
    keyboard.beginEntry(field,value.c_str());return;
  }
  if(action==Action::SaveText){
    if(wifiDraftActive&&keyboard.field==hmcnav::Field::WifiPass){
      if(keyboard.entryLength<8||keyboard.entryLength>63){keyboard.notice=Notice::Invalid;return;}
      if(!commitWifi(wifiDraftSsid,keyboard.entry)){keyboard.notice=Notice::Failed;return;}
      wifiDraftActive=false;wifiDraftSsid="";keyboard.back();keyboard.open(hmcnav::Screen::WifiStatus);keyboard.notice=Notice::Ready;return;
    }
    Config c;{Guard g(configLock);c=cfg;}using hmcnav::Field;
    if(keyboard.field==Field::WifiSsid){if(c.ssid!=keyboard.entry)c.pass="";c.ssid=keyboard.entry;}else if(keyboard.field==Field::WifiPass)c.pass=keyboard.entry;
    else if(keyboard.field==Field::TgToken)c.bot=keyboard.entry;else if(keyboard.field==Field::TgChat)c.chat=keyboard.entry;else if(keyboard.field==Field::DiscordUrl)c.discordUrl=keyboard.entry;
    if(!c.bot.length()||!c.chat.length())c.forwardTx=c.forwardRx=false;if(!c.discordUrl.length())c.discordTx=c.discordRx=false;
    if(saveLocalConfig(c)){keyboard.back();keyboard.notice=Notice::Saved;}return;
  }
  if(action==Action::ToggleTgTx||action==Action::ToggleTgRx||action==Action::ToggleDcTx||action==Action::ToggleDcRx||action==Action::ClearTg||action==Action::ClearDc||action==Action::ToggleBootSound){
    Config c;{Guard g(configLock);c=cfg;}
    if((action==Action::ToggleTgTx||action==Action::ToggleTgRx)&&(!tokenValid(c.bot)||!chatValid(c.chat))){keyboard.notice=Notice::Unavailable;return;}
    if((action==Action::ToggleDcTx||action==Action::ToggleDcRx)&&!hmcnotify::webhookValid(c.discordUrl.c_str())){keyboard.notice=Notice::Unavailable;return;}
    if(action==Action::ToggleTgTx)c.forwardTx=!c.forwardTx;else if(action==Action::ToggleTgRx)c.forwardRx=!c.forwardRx;else if(action==Action::ToggleDcTx)c.discordTx=!c.discordTx;else if(action==Action::ToggleDcRx)c.discordRx=!c.discordRx;
    else if(action==Action::ClearTg){c.bot="";c.chat="";c.forwardTx=c.forwardRx=false;}else if(action==Action::ClearDc){c.discordUrl="";c.discordTx=c.discordRx=false;}else c.bootSound=!c.bootSound;
    if(saveLocalConfig(c))keyboard.notice=Notice::Saved;return;
  }
  if(action==Action::Send) {
    if(playbackReserved){emergencyStop=true;keyboard.notice=Notice::Stopped;return;}
    command.op=CMD_TX;
    if(!morse::normalize(keyboard.text,command.text)){keyboard.notice=Notice::Empty;return;}
    if(localCommand(command))keyboard.notice=Notice::Sent;
  }else if(action==Action::LoadPreset||action==Action::PlayPreset) {
    const auto &preset=presets[keyboard.preset];
    if(!preset.text.length()){keyboard.notice=Notice::Empty;return;}
    if(action==Action::LoadPreset){keyboard.setText(preset.text.c_str());keyboard.open(hmcnav::Screen::Compose);keyboard.notice=Notice::Loaded;}
    else{command.op=CMD_TX;strlcpy(command.text,preset.text.c_str(),sizeof(command.text));if(localCommand(command))keyboard.notice=Notice::Sent;}
  }else if(action==Action::Finish){command.op=CMD_FINISH;localCommand(command);}
  else if(action==Action::ClearRx){command.op=CMD_CLEAR_RX;if(localCommand(command))keyboard.notice=Notice::Cleared;}
  else if(action==Action::ToggleMode){
    if(!ENABLE_I2S_MIC){keyboard.notice=Notice::Unavailable;return;}
    command.op=CMD_MODE;{Guard g(stateLock);command.mode=state.mode==KEY_MODE?MIC_MODE:KEY_MODE;}localCommand(command);
  }else if(action==Action::EditSpeed||action==Action::EditTone||action==Action::EditContrast||action==Action::EditThreshold){
    if(action==Action::EditThreshold&&!ENABLE_I2S_MIC){keyboard.notice=Notice::Unavailable;return;}
    Config c;{Guard g(configLock);c=cfg;}
    using hmcnav::Setting;
    keyboard.setting=action==Action::EditSpeed?Setting::Speed:action==Action::EditTone?Setting::Tone:action==Action::EditContrast?Setting::Contrast:Setting::Threshold;
    keyboard.editValue=action==Action::EditSpeed?c.wpm:action==Action::EditTone?c.hz:action==Action::EditContrast?c.oledContrast:c.db;
    keyboard.editMin=action==Action::EditSpeed?5:action==Action::EditTone?400:action==Action::EditContrast?16:15;
    keyboard.editMax=action==Action::EditSpeed?30:action==Action::EditTone?1200:action==Action::EditContrast?255:70;
    keyboard.editStep=action==Action::EditTone?50:action==Action::EditContrast?16:1;keyboard.open(hmcnav::Screen::Adjust);
  }else if(action==Action::ToggleAuto||action==Action::ToggleDim||action==Action::SaveSetting){
    Config c;{Guard g(configLock);c=cfg;}
    if(action==Action::ToggleAuto)c.autoWpm=!c.autoWpm;
    else if(action==Action::ToggleDim)c.oledDim=!c.oledDim;
    else{
      using hmcnav::Setting;unsigned value=keyboard.editValue;
      if(keyboard.setting==Setting::Speed)c.wpm=constrain(value,5u,30u);
      else if(keyboard.setting==Setting::Tone)c.hz=constrain(value,400u,1200u);
      else if(keyboard.setting==Setting::Contrast)c.oledContrast=constrain(value,16u,255u);
      else c.db=constrain(value,15u,70u);
    }
    if(saveLocalConfig(c)){if(action==Action::SaveSetting)keyboard.back();keyboard.notice=Notice::Saved;}
  }else if(action==Action::BleStop){pendingLocalBle=Action::None;bletools::stop();keyboard.notice=Notice::Stopped;}
  else if(action==Action::BleScan||action==Action::BleBeacon){
    int rc=action==Action::BleScan?bletools::scan():bletools::advertise("HMC-BEACON");
    if(rc==-2){if(pendingLocalBle==Action::None){localBleAt=millis();pendingLocalBle=action;}localBleTry=millis();keyboard.notice=Notice::Starting;}
    else{pendingLocalBle=Action::None;keyboard.notice=rc==-3?Notice::Busy:rc==-4?Notice::Cooldown:rc?Notice::Failed:Notice::Ready;}
  }
}
void serviceNavigation(){
  hmcnav::Event event;
  if(hmcbuttons::queue)while(xQueueReceive(hmcbuttons::queue,&event,0)==pdTRUE)applyKeyboardAction(keyboard.input(event,millis()));
  if(pendingLocalBle!=hmcnav::Action::None){
    if(keyboard.screen!=hmcnav::Screen::Ble)pendingLocalBle=hmcnav::Action::None;
    else if(millis()-localBleAt>3000){pendingLocalBle=hmcnav::Action::None;keyboard.notice=hmcnav::Notice::Failed;keyboard.changedAt=millis();}
    else if(millis()-localBleTry>=150){applyKeyboardAction(pendingLocalBle);keyboard.changedAt=millis();}
  }
  hmcbuttons::morseEnabled=keyboard.active&&keyboard.screen==hmcnav::Screen::Receive;
}
void keyboardGet(){
  if(!authorized())return;
  JsonDocument d;d["draft"]=keyboard.text;d["length"]=keyboard.length;d["maxLength"]=120;
  d["cursor"]=keyboard.cursor;d["page"]=hmcnav::screenName(keyboard.screen);d["menu"]=keyboard.menu;d["preset"]=keyboard.preset;
  d["depth"]=keyboard.depth;d["postPage"]=keyboard.postPage;
  d["field"]=keyboard.fieldTitle();d["entryLength"]=keyboard.typedLength();d["entryLimit"]=keyboard.limit();d["secret"]=keyboard.secret();if(!keyboard.secret())d["entry"]=keyboard.typedText();
  auto keys=d["keys"].to<JsonArray>();for(unsigned i=0;i<33;++i)keys.add(keyboard.caption(i).text);
  auto items=d["items"].to<JsonArray>();using hmcnav::Screen;
  if(keyboard.screen==Screen::Menu)for(unsigned i=0;i<4;++i)items.add(hmcnav::homeLabel(i));
  else if(hmcnav::isList(keyboard.screen))for(unsigned i=0;i<hmcnav::menuCount(keyboard.screen);++i)items.add(hmcnav::menuLabel(keyboard.screen,i));
  else if(keyboard.screen==Screen::Presets){for(const auto &p:presets)items.add(p.label.length()?p.label:"Empty slot");items.add("Back");}
  else if(keyboard.screen==Screen::WifiScan){for(unsigned i=0;i<wifiNetworks.count;++i)items.add(wifiNetworks.items[i].ssid);items.add("Rescan");items.add("Back");}
  else if(keyboard.screen==Screen::Confirm){items.add("Clear");items.add("Back");}
  else if(keyboard.screen==Screen::Adjust){items.add("Save");items.add("Back");d["value"]=keyboard.editValue;}
  else if(keyboard.screen==Screen::BuzzerTest){items.add("Play sound");items.add("Back");}
  else if(keyboard.screen!=Screen::Compose&&keyboard.screen!=Screen::Receive)items.add("Back");
  bool playing=playbackReserved.load();
  d["notice"]=hmcnav::noticeText(keyboard.notice==hmcnav::Notice::Sent&&!playing?hmcnav::Notice::Ready:keyboard.notice);d["controller"]=hmcbuttons::ready.load();
  d["seen"]=hmcbuttons::seenMask.load();d["pressed"]=hmcbuttons::downMask.load();d["tx"]=playing;d["buttonWiring"]=hmcbuttons::wiring();
  d["micAvailable"]=bool(ENABLE_I2S_MIC);
  jsonReply(200,d);
}
void keyboardPost(){
  JsonDocument d;if(!readBody(d))return;
  if(!d["op"].is<const char*>()){fail(400,"Keyboard operation must be a string");return;}
  String op=d["op"].as<String>();hmcnav::Action action=hmcnav::Action::None;
  if(op=="item"){
    using hmcnav::Screen;auto screen=keyboard.screen;
    unsigned count=screen==Screen::Menu?4:hmcnav::isList(screen)?hmcnav::menuCount(screen):screen==Screen::WifiScan?keyboard.wifiCount+2:screen==Screen::Presets?7:screen==Screen::Confirm||screen==Screen::Adjust||screen==Screen::BuzzerTest?2:screen==Screen::Compose||screen==Screen::Receive?0:1;
    if(!d["index"].is<unsigned>()||d["index"].as<unsigned>()>=count){fail(400,"Menu item unavailable on this page");return;}
    keyboard.menu=d["index"].as<unsigned>();
    if(screen==Screen::BuzzerTest&&keyboard.menu==1)keyboard.back();else action=keyboard.input({hmcnav::Button::Select,hmcnav::Edge::Release,false},millis());
  }else if(op=="key"){
    if(!d["index"].is<unsigned>()||d["index"].as<unsigned>()>=33){fail(400,"Key index must be 0-32");return;}
    if(keyboard.screen!=hmcnav::Screen::Compose)keyboard.go(hmcnav::Screen::Compose);keyboard.changedAt=millis();action=keyboard.choose(d["index"]);
  }else if(op=="draft"){
    if(!d["text"].is<const char*>()||!keyboard.setText(d["text"].as<const char*>())){fail(400,"Use supported Morse characters; draft limit 120");return;}
    keyboard.go(hmcnav::Screen::Compose);keyboard.notice=hmcnav::Notice::Ready;
  }else if(op=="nav"){
    String b=d["button"]|"";
    if(b=="back")keyboard.back();
    else{
      int index=b=="up"?0:b=="down"?1:b=="left"?2:b=="right"?3:b=="select"?4:-1;
      if(index<0){fail(400,"Unknown navigation button");return;}
      action=keyboard.input({static_cast<hmcnav::Button>(index),index==4?hmcnav::Edge::Release:hmcnav::Edge::Press,false},millis());
    }
  }else if(op=="page"){
    String page=d["page"]|"";int index=-1;
    for(unsigned i=0;i<unsigned(hmcnav::Screen::Count);++i){auto s=static_cast<hmcnav::Screen>(i);if(s!=hmcnav::Screen::Adjust&&s!=hmcnav::Screen::Confirm&&page==hmcnav::screenName(s))index=i;}
    if(page=="home")keyboard.go(hmcnav::Screen::Menu);
    else if(index>=0)keyboard.go(static_cast<hmcnav::Screen>(index));
    else{fail(400,"Unknown device page");return;}
  }else{fail(400,"Unknown keyboard operation");return;}
  keyboard.active=true;keyboard.changedAt=millis();applyKeyboardAction(action);
  hmcbuttons::morseEnabled=keyboard.screen==hmcnav::Screen::Receive;
  accepted();
}
uint32_t oledGeneration = 0;
uint32_t lastOledProbe = 0;
bool probeOled() {
  for (uint8_t address : {uint8_t(0x3c), uint8_t(0x3d)}) {
    Wire.beginTransmission(address);
    if (Wire.endTransmission() == 0) {
      if (oledAddress == address && oledOK) return true;
      if (oled.begin(SSD1306_SWITCHCAPVCC, address, false, false)) {
        oledAddress = address;
        ++oledGeneration;
        return true;
      }
    }
  }
  oledAddress = 0;
  return false;
}
void updateOled(uint32_t now, bool connected) {
  // I2C work stays in the network/UI loop, outside the real-time Morse task.
  // At most eight full frames/sec, with no blocking animation delays.
  if (now - lastOledProbe >= 5000) {
    lastOledProbe = now;
    oledOK = probeOled();
  }
  static uint32_t splashAt=0;static bool splashStarted=false;
  if(!splashStarted){splashAt=now;splashStarted=true;}
  unsigned framePeriod=!keyboard.active&&now-splashAt<2000?50:100;
  if (!oledOK || now - lastOled < framePeriod) return;
  lastOled = now;
  State s;
  morse::SignalTimeline trace;
  { Guard g(stateLock); s = state; trace = signalTimeline; }
  hmcdisplay::Model m;
  m.keyboard=keyboard;m.keyboard.changedAt-=bootAt;if(m.keyboard.lastTypedAt)m.keyboard.lastTypedAt-=bootAt;m.navReady=hmcbuttons::ready;
  for(unsigned i=0;i<6;++i)strlcpy(m.presetLabels[i],presets[i].label.c_str(),sizeof(m.presetLabels[i]));
  unsigned view, contrast;
  bool dim;
  {
    Guard g(configLock);
    view = cfg.oledView; contrast = cfg.oledContrast; dim = cfg.oledDim;
    strlcpy(m.ssid, cfg.ssid.c_str(), sizeof(m.ssid));
    using hmcnav::Screen;
    if(keyboard.screen==Screen::SignalSetup){snprintf(m.rowValues[0],7,"%uWPM",cfg.wpm);snprintf(m.rowValues[1],7,"%uHZ",cfg.hz);}
    else if(keyboard.screen==Screen::DisplaySetup){snprintf(m.rowValues[0],7,"%u",cfg.oledContrast);strlcpy(m.rowValues[1],cfg.oledDim?"ON":"OFF",7);strlcpy(m.rowValues[2],cfg.bootSound?"ON":"OFF",7);}
    else if(keyboard.screen==Screen::InputSetup){strlcpy(m.rowValues[0],cfg.autoWpm?"ON":"OFF",7);strlcpy(m.rowValues[1],s.mode==MIC_MODE?"MIC":"KEY",7);if(ENABLE_I2S_MIC)snprintf(m.rowValues[2],7,"%uDB",cfg.db);else strlcpy(m.rowValues[2],"OFF",7);}

  }
  {
    Guard g(configLock);using hmcnav::Screen;auto screen=keyboard.screen;bool tg=tokenValid(cfg.bot)&&chatValid(cfg.chat),dc=hmcnotify::webhookValid(cfg.discordUrl.c_str());
    auto value=[&](unsigned row,bool set){strlcpy(m.rowValues[row],set?"SET":"EMPTY",7);};
    if(screen==Screen::Connections){value(0,cfg.ssid.length());value(1,tg);value(2,dc);strlcpy(m.statusLine,"SET = CONFIGURED",22);}
    else if(screen==Screen::WifiSetup){strlcpy(m.rowValues[0],wifiScanning?"SCAN":"",7);strlcpy(m.statusLine,hmcwifi::label(wifiLink.state),22);}
    else if(screen==Screen::WifiManual){value(0,cfg.ssid.length());value(1,cfg.pass.length());strlcpy(m.statusLine,hmcwifi::label(wifiLink.state),22);}
    else if(screen==Screen::TelegramSetup){value(0,cfg.bot.length());value(1,cfg.chat.length());strlcpy(m.rowValues[2],cfg.forwardTx||cfg.forwardRx?"ON":"OFF",7);strlcpy(m.statusLine,hmcnotify::state(tg,cfg.bot.length()||cfg.chat.length()),22);}
    else if(screen==Screen::DiscordSetup){value(0,dc);strlcpy(m.rowValues[1],cfg.discordTx||cfg.discordRx?"ON":"OFF",7);strlcpy(m.statusLine,hmcnotify::state(dc),22);}
    else if(screen==Screen::TelegramOptions||screen==Screen::DiscordOptions){bool isTg=screen==Screen::TelegramOptions;strlcpy(m.rowValues[0],(isTg?cfg.forwardTx:cfg.discordTx)?"ON":"OFF",7);strlcpy(m.rowValues[1],(isTg?cfg.forwardRx:cfg.discordRx)?"ON":"OFF",7);}
  }
  static char previousText[121] = {}, previousPending[8] = {};
  static uint32_t activeAt = 0, previousId = 0;
  static unsigned previousView = 0, appliedContrast = 999, previousMode = 0, previousContrast = 160;
  static bool previousDim = true;
  static uint32_t seenGeneration = 0;
  if (seenGeneration != oledGeneration) { appliedContrast = 999; seenGeneration = oledGeneration; activeAt = now; if(!keyboard.active)splashAt=now; }
  if (s.tx || s.key || strcmp(s.text,previousText) || strcmp(s.pending,previousPending) ||
      previousId != nextId || previousView != view || previousMode != s.mode || previousContrast != contrast || previousDim != dim || now-keyboard.changedAt<8000) {
    activeAt = now;
    strlcpy(previousText,s.text,sizeof(previousText));
    strlcpy(previousPending,s.pending,sizeof(previousPending));
    previousId = nextId; previousView = view; previousMode = s.mode;
    previousContrast = contrast; previousDim = dim;
  }
  uint32_t idle = now - activeAt;
  unsigned targetContrast = dim && idle > 60000 && now - bootAt >= 800 ? 16 : contrast;
  if (targetContrast != appliedContrast) {
    oled.ssd1306_command(SSD1306_SETCONTRAST);
    oled.ssd1306_command(uint8_t(targetContrast));
    appliedContrast = targetContrast;
  }
  m.ms = now; m.uptime = now/1000;
  m.tx = s.tx; m.signal = s.tone; m.mic = s.mode == MIC_MODE;
  m.txWpm = s.txWpm; m.rxWpm = s.rxWpm; m.letter = s.letter;
  m.autoSpeed = s.autoWpm; m.speedLocked = s.speedLocked;
  m.online = connected; m.rssi = connected ? WiFi.RSSI() : 0;
  m.wifiState=wifiLink.state;m.wifiError=wifiLink.error;m.wifiScanning=wifiScanning;m.wifiScanDone=wifiScanDone;m.wifiScanFailed=wifiScanFailed;
  m.wifiFirst=(keyboard.menu<=keyboard.wifiCount?keyboard.menu:keyboard.wifiCount)/3*3;
  for(unsigned i=0;i<3;++i){unsigned item=m.wifiFirst+i;if(item<wifiNetworks.count){strlcpy(m.wifiNames[i],wifiNetworks.items[item].ssid,33);m.wifiSecure[i]=wifiNetworks.items[item].secure;m.wifiSupported[i]=wifiNetworks.items[item].supported;}}
  m.clients = WiFi.softAPgetStationNum();
  m.heap = ESP.getFreeHeap(); m.minHeap = ESP.getMinFreeHeap();
  m.totalHeap = ESP.getHeapSize(); m.cpuMHz = ESP.getCpuFreqMHz();
  strlcpy(m.ap,apName.c_str(),sizeof(m.ap));
  strlcpy(m.wifiPass,HMC_AP_PASSWORD,sizeof(m.wifiPass));
  strlcpy(m.ip,(connected ? WiFi.localIP().toString() : WiFi.softAPIP().toString()).c_str(),sizeof(m.ip));
  strlcpy(m.pending,s.pending,sizeof(m.pending));
  strlcpy(m.message,s.text,sizeof(m.message));
  portENTER_CRITICAL(&bletools::mux);
  m.bleCount = bletools::count;
  portEXIT_CRITICAL(&bletools::mux);
  m.bleState = bletools::scanning ? 2 : bletools::beacon ? 3 : bletools::ready ? 1 : 0;
  for (uint32_t id = trace.next-trace.count; id < trace.next; ++id) {
    const auto &p = trace.items[(id-1)%trace.capacity];
    uint32_t age = now - (p.at+p.duration);
    if (!p.on || age >= 5000) continue;
    uint32_t startAge = now-p.at;
    unsigned left = (5000-(startAge>5000?5000:startAge))*64/5000;
    unsigned right = (5000-age)*64/5000;
    if (right <= left) right = left+1;
    for (unsigned i=left; i<right && i<64; ++i) m.wave[i] = 1;
  }
  if (s.tone) m.wave[63] = 1;
  using hmcnav::Screen;
  if(keyboard.screen==Screen::Ble){if(bletools::scanning)strlcpy(m.rowValues[0],"RUN",7);else if(bletools::ready)snprintf(m.rowValues[0],7,"%uSEEN",m.bleCount);strlcpy(m.rowValues[1],bletools::beacon?"ON":"OFF",7);}
  if(!keyboard.active&&now-splashAt<2000){m.page=hmcdisplay::Page::Splash;m.ms=now-splashAt;}
  else if(keyboard.active||view==0){
    auto screen=keyboard.screen;
    m.page=screen==Screen::Compose?hmcdisplay::Page::Keyboard:screen==Screen::Menu?hmcdisplay::Page::Menu:screen==Screen::Receive?hmcdisplay::Page::Signal:screen==Screen::Presets?hmcdisplay::Page::Presets:screen==Screen::Device?hmcdisplay::Page::Device:screen==Screen::Network?hmcdisplay::Page::Network:screen==Screen::Post?hmcdisplay::Page::Post:screen==Screen::Adjust?hmcdisplay::Page::Adjust:screen==Screen::Confirm?hmcdisplay::Page::Confirm:screen==Screen::About?hmcdisplay::Page::About:screen==Screen::BuzzerTest?hmcdisplay::Page::BuzzerTest:screen==Screen::MicTest?hmcdisplay::Page::MicTest:screen==Screen::WifiScan?hmcdisplay::Page::WifiScan:screen==Screen::WifiStatus?hmcdisplay::Page::WifiStatus:hmcdisplay::Page::List;
  }else m.page=view==1?hmcdisplay::Page::Signal:view==2?hmcdisplay::Page::Device:view==3?hmcdisplay::Page::Network:view==4?hmcdisplay::Page::Ble:view==5?hmcdisplay::Page::Post:view==6?hmcdisplay::Page::Keyboard:hmcdisplay::Page::Menu;
  m.post = readPostReport();m.micEnabled=ENABLE_I2S_MIC;m.micReady=micOK;m.micFault=micFailed;m.micLevel=unsigned(constrain((20*log10f(fmaxf(micRms.load(),1e-8f))+70)/.7f,0.f,100.f));m.buzzerActive=buzzerTesting;m.buzzerCount=buzzerTests;if(m.page==hmcdisplay::Page::MicTest)m.signal=micTone;
  hmcdisplay::Frame frame = hmcdisplay::render(m);
  memcpy(oled.getBuffer(),frame.data,sizeof(frame.data));
  oled.display();
}
void stationSetup() {
  Serial.begin(115200);
  bootAt = millis();
  stateLock = xSemaphoreCreateMutex();
  configLock = xSemaphoreCreateMutex();
  commands = xQueueCreate(6, sizeof(Command));
  events = xQueueCreate(12, sizeof(Event));
  telegramQueue = xQueueCreate(8, sizeof(TelegramJob));
  if (!stateLock || !configLock || !commands || !events || !telegramQueue) {
    Serial.println("FATAL: allocation failed");
    while (true)
      delay(1000);
  }
  loadConfig();
  keyboard.go(hmcnav::viewScreen(cfg.oledView));
  pinMode(PIN_BUZZER, OUTPUT);
  Wire.begin(PIN_SDA, PIN_SCL);
  Wire.setTimeOut(40);
  Wire.setClock(400000);
  hmcbuttons::queue=xQueueCreate(24,sizeof(hmcnav::Event));
  hmcbuttons::ready=hmcbuttons::begin();
  hmcbuttons::taskOK=hmcbuttons::queue&&xTaskCreate(hmcbuttons::task,"buttons",4096,nullptr,2,nullptr)==pdPASS;
  if(!hmcbuttons::taskOK)Serial.println("ERROR: button task allocation failed");
  oledOK = probeOled();
  if (!oledOK) Serial.println("OLED not detected at 0x3C/0x3D; retrying every 5 seconds");
  WiFi.persistent(false);
  WiFi.mode(WIFI_AP_STA);
  WiFi.setSleep(false);WiFi.setAutoReconnect(false);
  WiFi.onEvent([](WiFiEvent_t,WiFiEventInfo_t info){wifiDisconnectReason=info.wifi_sta_disconnected.reason;},ARDUINO_EVENT_WIFI_STA_DISCONNECTED);
  apName = HMC_AP_NAME;
  bool apOK = WiFi.softAP(apName.c_str(), HMC_AP_PASSWORD, 6, false, 3);
  postApOK=apOK;
  if (!apOK)
    Serial.println("ERROR: AP start failed");
  Serial.printf("\nWi-Fi: %s\nWi-Fi password: %s\nWeb access key: %s\nOpen http://192.168.4.1\n",
                apName.c_str(), HMC_AP_PASSWORD, deviceKey.c_str());
  requestWifiConnection();
  configTime(0, 0, "pool.ntp.org", "time.google.com");
  setupWeb();
  engineOK = xTaskCreate(engineTask, "morse", 6144, nullptr, 3, nullptr) == pdPASS;
  if (!engineOK) {
    Serial.println("FATAL: Morse task failed");
    while (true)
      delay(1000);
  }
  telegramOK = xTaskCreate(telegramTask, "telegram", 12288, nullptr, 1, nullptr) == pdPASS;
  if (!telegramOK)
    emit("ERROR", "Telegram task allocation failed");
#if ENABLE_I2S_MIC
  if (xTaskCreate(audioTask, "audio", 6144, nullptr, 2, nullptr) != pdPASS)
    { micFailed=true; emit("ERROR", "Microphone task allocation failed"); }
#endif
  if(cfg.bootSound){Command beep;beep.op=CMD_BEEP;beep.wpm=20;strlcpy(beep.text,"EE",sizeof(beep.text));if(localCommand(beep))buzzerTesting=true;}
  printPostReport();
}
void stationLoop() {
  serviceWifi(millis());
  serviceNavigation();
  server.handleClient();
  Event e;
  while (xQueueReceive(events, &e, 0) == pdTRUE)
    record(e);
  uint32_t now = millis();
  bool connected = wifiConnected();
  if (connected && !wifiWasConnected) {
    Serial.print("LAN address: http://");
    Serial.println(WiFi.localIP());
    MDNS.end();
    MDNS.begin("morse");
    MDNS.addService("http", "tcp", 80);
  }
  wifiWasConnected = connected;
  servicePost(now);
  updateOled(now,connected);
  delay(2);
}
#if HMC_QA
#include "tests/target_qa.h"
#endif
