#pragma once
#include <math.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>
namespace morse {
constexpr size_t MAX_TEXT = 120, MAX_CODE = 1000, MAX_PULSES = 1600;
struct Entry {
  char c;
  const char *code;
};
static const Entry alphabet[] = {
    {'A', ".-"},    {'B', "-..."},   {'C', "-.-."},   {'D', "-.."},    {'E', "."},
    {'F', "..-."},  {'G', "--."},    {'H', "...."},   {'I', ".."},     {'J', ".---"},
    {'K', "-.-"},   {'L', ".-.."},   {'M', "--"},     {'N', "-."},     {'O', "---"},
    {'P', ".--."},  {'Q', "--.-"},   {'R', ".-."},    {'S', "..."},    {'T', "-"},
    {'U', "..-"},   {'V', "...-"},   {'W', ".--"},    {'X', "-..-"},   {'Y', "-.--"},
    {'Z', "--.."},  {'0', "-----"},  {'1', ".----"},  {'2', "..---"},  {'3', "...--"},
    {'4', "....-"}, {'5', "....."},  {'6', "-...."},  {'7', "--..."},  {'8', "---.."},
    {'9', "----."}, {'.', ".-.-.-"}, {',', "--..--"}, {'?', "..--.."}, {'/', "-..-."},
    {'=', "-...-"}, {'+', ".-.-."},  {'-', "-....-"}, {'@', ".--.-."}, {'!', "-.-.--"},
    {'(', "-.--."}, {')', "-.--.-"}, {':', "---..."}, {'\'', ".----."}};
inline char upper(char c) { return c >= 'a' && c <= 'z' ? char(c - 32) : c; }
inline const char *encodeChar(char c) {
  for (auto &e : alphabet)
    if (e.c == upper(c))
      return e.code;
  return nullptr;
}
inline char decodeChar(const char *s) {
  for (auto &e : alphabet)
    if (!strcmp(s, e.code))
      return e.c;
  return '?';
}
inline bool normalize(const char *in, char *out) {
  size_t n = 0;
  bool space = false;
  for (; *in; ++in) {
    if (*in == ' ' || *in == '\n' || *in == '\r' || *in == '\t') {
      space = n > 0;
      continue;
    }
    if (!encodeChar(*in))
      return false;
    if (space) {
      if (n >= MAX_TEXT)
        return false;
      out[n++] = ' ';
      space = false;
    }
    if (n >= MAX_TEXT)
      return false;
    out[n++] = upper(*in);
  }
  out[n] = 0;
  return n > 0;
}
inline bool encode(const char *text, char *out, size_t cap) {
  if (!cap) return false;
  size_t n = 0;
  out[0] = 0;
  for (size_t i = 0; text[i]; i++) {
    const char *s = text[i] == ' ' ? "/" : encodeChar(text[i]);
    if (!s)
      return false;
    size_t l = strlen(s);
    if (n + l + (i ? 1 : 0) >= cap)
      return false;
    if (i)
      out[n++] = ' ';
    memcpy(out + n, s, l);
    n += l;
  }
  out[n] = 0;
  return true;
}
inline bool decodeText(const char *input, char *out) {
  char token[8] = {};
  size_t t = 0, n = 0;
  bool word = false;
  auto flush = [&]() {
    if (!t)
      return true;
    token[t] = 0;
    char c = decodeChar(token);
    if (!encodeChar(c) || strcmp(encodeChar(c), token))
      return false;
    if (word && n) {
      if (n >= MAX_TEXT)
        return false;
      out[n++] = ' ';
    }
    word = false;
    if (n >= MAX_TEXT)
      return false;
    out[n++] = c;
    t = 0;
    return true;
  };
  for (; *input; ++input) {
    char c = *input;
    if (c == '.' || c == '-') {
      if (t >= 6)
        return false;
      token[t++] = c;
    } else if (c == ' ' || c == '\n' || c == '\r' || c == '\t' || c == '/') {
      if (!flush())
        return false;
      if (c == '/')
        word = true;
    } else
      return false;
  }
  if (!flush())
    return false;
  out[n] = 0;
  return n > 0;
}
inline int ledBit(char c) { // Physical Q bit in the existing four-register chain.
  const char map[33] = "  ETIANMSURWDKGOHVF L PJBXCYZQ  ";
  for (int i = 2; i < 30; i++)
    if (map[i] == upper(c))
      return i;
  return -1;
}
inline bool due(uint32_t now, uint32_t target) { return int32_t(now - target) >= 0; }
struct Pulse {
  uint8_t units;
  bool on;
  char letter;
};
class Transmitter {
  Pulse pulses[MAX_PULSES];
  size_t count = 0, index = 0;
  uint32_t deadline = 0;
  uint16_t unit = 100;

public:
  bool active = false, on = false;
  char letter = 0;
  bool start(const char *text, unsigned wpm, uint32_t now) {
    if (active || wpm < 5 || wpm > 30)
      return false;
    count = 0;
    index = 0;
    unit = 1200 / wpm;
    for (size_t i = 0; text[i]; ++i) {
      if (text[i] == ' ')
        continue;
      const char *c = encodeChar(text[i]);
      if (!c)
        return false;
      for (size_t j = 0; c[j]; ++j) {
        if (count + 2 > MAX_PULSES)
          return false;
        pulses[count++] = {uint8_t(c[j] == '-' ? 3 : 1), true, text[i]};
        if (c[j + 1])
          pulses[count++] = {1, false, text[i]};
      }
      if (text[i + 1]) {
        if (count == MAX_PULSES)
          return false;
        pulses[count++] = {uint8_t(text[i + 1] == ' ' ? 7 : 3), false, text[i]};
      }
    }
    if (!count)
      return false;
    active = true;
    on = pulses[0].on;
    letter = pulses[0].letter;
    deadline = now + unit * pulses[0].units;
    return true;
  }
  bool tick(uint32_t now) {
    if (!active || !due(now, deadline))
      return false;
    if (++index >= count) {
      stop();
      return true;
    }
    on = pulses[index].on;
    letter = pulses[index].letter;
    // Never compress overdue elements into a burst after scheduler starvation.
    deadline = now + unit * pulses[index].units;
    return false;
  }
  void stop() {
    active = false;
    on = false;
    letter = 0;
  }
};
class Receiver {
  char symbols[8] = {};
  size_t sn = 0, n = 0;
  bool level = false, wordDone = false, invalid = false;
  uint32_t startAt = 0, endAt = 0;
  uint16_t unit = 100;
  void add(char c) {
    if (n < MAX_TEXT) {
      text[n++] = c;
      text[n] = 0;
      lastChar = c;
    } else
      overflow = true;
  }
  void letter() {
    if (!sn && !invalid)
      return;
    symbols[sn] = 0;
    add(invalid ? '?' : decodeChar(symbols));
    sn = 0;
    symbols[0] = 0;
    invalid = false;
  }

public:
  char text[MAX_TEXT + 1] = {};
  char lastChar = 0;
  bool ready = false, overflow = false;
  void reset(unsigned wpm = 12) {
    if (wpm < 5) wpm = 5;
    if (wpm > 30) wpm = 30;
    unit = 1200 / wpm;
    sn = n = 0;
    level = wordDone = invalid = ready = overflow = false;
    text[0] = symbols[0] = lastChar = 0;
    startAt = endAt = 0;
  }
  void edge(bool high, uint32_t now) {
    if (high == level || ready)
      return;
    if (high) {
      tick(now);
      if (ready)
        return;
      startAt = now;
      level = true;
      wordDone = false;
    } else {
      level = false;
      uint32_t d = now - startAt;
      if (d < unit / 5)
        return;
      if (d > unit * 6u || sn >= 6)
        invalid = true;
      else
        symbols[sn++] = d >= unit * 2u ? '-' : '.';
      symbols[sn] = 0;
      endAt = now;
    }
  }
  void tick(uint32_t now) {
    if (level || ready)
      return;
    uint32_t gap = now - endAt;
    if ((sn || invalid) && gap >= unit * 2u)
      letter();
    if (n && !wordDone && gap >= unit * 5u) {
      if (text[n - 1] != ' ')
        add(' ');
      wordDone = true;
    }
    uint32_t finishGap = unit * 15u;
    if (finishGap < 1800)
      finishGap = 1800;
    if (n && (gap >= finishGap || overflow))
      finish();
  }
  void finish() {
    letter();
    while (n && text[n - 1] == ' ')
      text[--n] = 0;
    ready = n > 0;
  }
  const char *pending() const { return symbols; }
  void setUnit(unsigned ms) { unit = ms < 40 ? 40 : ms > 240 ? 240 : ms; }
};
struct ToneResult {
  float rms, ratio;
  bool tone;
};
inline ToneResult detectTone(const float *data, size_t n, float fs, float hz, float floor,
                             bool previous) {
  if (!n)
    return {0, 0, false};
  float mean = 0;
  for (size_t i = 0; i < n; i++)
    mean += data[i];
  mean /= n;
  float energy = 0;
  for (size_t i = 0; i < n; i++) {
    float x = data[i] - mean;
    energy += x * x;
  }
  float best = 0;
  for (int delta = -1; delta <= 1; delta++) {
    float a = 2 * cosf(6.28318530718f * (hz + delta * 35) / fs), q1 = 0, q2 = 0;
    for (size_t i = 0; i < n; i++) {
      float q = data[i] - mean + a * q1 - q2;
      q2 = q1;
      q1 = q;
    }
    float p = q1 * q1 + q2 * q2 - a * q1 * q2;
    if (p > best)
      best = p;
  }
  float rms = sqrtf(energy / n), ratio = energy > 1e-12f ? 2 * best / (n * energy) : 0;
  return {rms, ratio, rms > floor * (previous ? .7f : 1.f) && ratio > (previous ? .22f : .38f)};
}
} // namespace morse
