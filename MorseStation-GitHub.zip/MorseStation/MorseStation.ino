// Keep all supplied .h and .cpp files in this sketch folder.
void stationSetup();
void stationLoop();
void setup() { stationSetup(); }
void loop() { stationLoop(); }
