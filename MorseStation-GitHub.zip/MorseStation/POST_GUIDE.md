# HMC 3.3 / Power-on self-test

POST covers **13 items**: OLED, button input setup, five buttons, buzzer, optional I2S mic, flash, settings/NVS, RAM and Wi-Fi AP. It prints at **115200 baud**, appears as five manually selected OLED pages, and is shown in web Device & BLE. Pocket keyboard shows the physical button checks too. Current menu plan: OLED_MENU_PLAN.md; verified results: docs/VALIDATION.md.

Type **POST** + Enter to repeat and open the OLED report. Up/Down change pages; Select/Left returns. Type **HOME** to return to the four-icon home screen. **NET** reports router/clock/Telegram readiness without credentials; **WIFISCAN** starts a Wi-Fi scan. AP initialization PASS is separate from router connectivity. Commands are case-insensitive; use Newline or Both NL & CR. HELP lists commands. Changes are checked every 500 ms and printed once per status change.

Tools > System > Tests includes POST report, Buzzer test and Mic test. Buzzer
test uses Select to play a short EE pattern; Left returns. The same pattern
plays at boot when Setup > Display > Boot sound is enabled (default on).
Playback completion is recorded, but cannot verify that sound was heard.
Mic test displays Disabled in the non-mic version. With the optional mic
enabled and compatible wiring, it shows driver status, level and tone detection.

| Status | Meaning |
|---|---|
| FOUND | OLED ACK/framebuffer initialized |
| MISSING | OLED not found at 0x3C/0x3D |
| CHECK | Physical component requires manual verification |
| HELD | Debounced button held before its first observed complete cycle |
| SEEN | Physical press-and-release observed this boot |
| OFF | Optional microphone disabled in this build |
| WAIT | Microphone driver initializing |
| DRIVER | I2S initialized; physical mic/audio still unverified |
| PASS | GPIO pullup input task, internal flash, NVS, RAM or AP initialization passed |
| FAIL | Corresponding initialization/readiness failed |

With only the ESP32 connected: OLED should show MISSING; BUTTONS should show PASS for initialized GPIO inputs, five buttons and buzzer CHECK, mic OFF, and internal readiness PASS. Browser operation continues when optional peripherals are missing.

OLED is retried every five seconds. Five switches use GPIO3/4/7/10/1 internal pullups, active low. BUTTONS PASS proves setup, not switch presence. Press/release all five for SEEN. No separate KEY/MODE inputs or LED bank remain.

ACK cannot prove OLED pixels/controller are correct. Missing and unpressed buttons look alike: physically press/release each for SEEN. Web controls never fabricate physical tests. Listen to the buzzer; I2S initialization cannot prove mic presence or audio quality. See WIRING_KEYBOARD.md for assembly acceptance checks.
