# Direct OLED/button/piezo wiring / HMC 3.3

The complete current guide is [docs/WIRING.md](docs/WIRING.md), with a [connection diagram](docs/assets/wiring.png) and [Wokwi import](docs/WOKWI.md).

Default pins: OLED SDA5/SCL0 at 3.3 V; Up3, Down4, Left7, Right10, Select1 to GND; buzzer control6. Native USB18/19 and boot2/8/9 remain unused. Microphone is disabled in this direct-button build.

For microphone support while keeping these five direct buttons, use the
[separate no-expander microphone build and wiring](docs/WIRING_MIC_DIRECT.md).
It uses GPIO2 with a required 10k pullup, WS21 and SD20.
