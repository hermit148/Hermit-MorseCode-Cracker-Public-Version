#pragma once
#include "BuildConfig.h"
#include <stdint.h>

namespace hmcpost {
enum class Status : uint8_t { Check, Found, Missing, Seen, Off, Driver, Pass, Fail, Wait, Held };
enum Item : unsigned { Oled, Controller, Up, Down, Left, Right, Select, Buzzer, Mic, Flash, Nvs, Ram, Wifi, Count };
struct Report { Status items[Count] = {}; };
constexpr const char *name(unsigned item) {
  return item==Oled?"OLED":item==Controller?(BUTTONS_USE_MCP23017?"BUTTON IC":"BUTTONS"):item==Up?"UP":item==Down?"DOWN":item==Left?"LEFT":item==Right?"RIGHT":item==Select?"SELECT":item==Buzzer?"BUZZER":
         item==Mic?"I2S MIC":item==Flash?"FLASH":item==Nvs?"SETTINGS":item==Ram?"RAM":"WI-FI AP";
}
constexpr const char *label(Status status) {
  return status==Status::Found?"FOUND":status==Status::Missing?"MISSING":status==Status::Seen?"SEEN":
         status==Status::Off?"OFF":status==Status::Driver?"DRIVER":status==Status::Pass?"PASS":
         status==Status::Fail?"FAIL":status==Status::Wait?"WAIT":status==Status::Held?"HELD":"CHECK";
}
constexpr Status button(bool observedCycle, bool down) {
  return observedCycle?Status::Seen:down?Status::Held:Status::Check;
}
constexpr Status microphone(bool enabled, bool ready, bool failed) {
  return !enabled?Status::Off:failed?Status::Fail:ready?Status::Driver:Status::Wait;
}
constexpr unsigned missing(const Report &report) {
  unsigned n=0;for(unsigned i=0;i<Count;++i)if(report.items[i]==Status::Missing||report.items[i]==Status::Fail)++n;return n;
}
}
