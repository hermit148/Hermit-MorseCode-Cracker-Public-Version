#pragma once
#include <Arduino.h>
#include <ArduinoJson.h>
#include <atomic>
#include <sdkconfig.h>
#if !defined(CONFIG_NIMBLE_ENABLED)
#error "HMC BLE tools require the NimBLE-enabled Arduino-ESP32 core 3.3.12. See HMC_FEATURES.md."
#endif
#include <esp32-hal-alloc-ble-mem.h>
#include <nimble/nimble_port.h>
#include <nimble/nimble_port_freertos.h>
#include <host/ble_hs.h>
#include <host/ble_gap.h>
#include <host/ble_hs_adv.h>
#include <host/util/util.h>

// Uses the NimBLE host shipped with Arduino-ESP32 3.3.12. No GATT server,
// connections, scan-response requests, or unbounded advertisement cache.
namespace bletools {
struct Device {
  uint8_t address[6] = {}, type = 0;
  char name[25] = {};
  int rssi = 0;
};
static portMUX_TYPE mux = portMUX_INITIALIZER_UNLOCKED;
static Device devices[20];
static unsigned count = 0, dropped = 0;
static std::atomic<bool> ready{false}, scanning{false}, beacon{false};
static std::atomic<int> lastError{0};
static bool started = false;
static uint8_t ownType = 0;
static uint32_t lastScan = 0;
static bool scannedBefore = false;
static char beaconName[21] = "HMC-BEACON";

static int onEvent(ble_gap_event *event, void *) {
  if (event->type == BLE_GAP_EVENT_DISC) {
    const auto &ad = event->disc;
    ble_hs_adv_fields fields{};
    bool parsed = ble_hs_adv_parse_fields(&fields, ad.data, ad.length_data) == 0;
    portENTER_CRITICAL(&mux);
    unsigned slot = 0;
    for (; slot < count; ++slot)
      if (devices[slot].type == ad.addr.type && !memcmp(devices[slot].address, ad.addr.val, 6)) break;
    if (slot == 20) { ++dropped; portEXIT_CRITICAL(&mux); return 0; }
    if (slot == count) { devices[slot] = Device{}; ++count; }
    auto &d = devices[slot];
    memcpy(d.address, ad.addr.val, 6); d.type = ad.addr.type; d.rssi = ad.rssi;
    if (parsed && fields.name && fields.name_len) {
      unsigned n = fields.name_len < 24 ? fields.name_len : 24;
      for (unsigned i = 0; i < n; ++i)
        d.name[i] = fields.name[i] >= 32 && fields.name[i] <= 126 ? fields.name[i] : '?';
      d.name[n] = 0;
    }
    portEXIT_CRITICAL(&mux);
  } else if (event->type == BLE_GAP_EVENT_DISC_COMPLETE) {
    scanning = false;
    if (event->disc_complete.reason) lastError = event->disc_complete.reason;
  } else if (event->type == BLE_GAP_EVENT_ADV_COMPLETE) {
    beacon = false;
  }
  return 0;
}
static void onSync() {
  int rc = ble_hs_util_ensure_addr(0);
  if (!rc) rc = ble_hs_id_infer_auto(0, &ownType);
  lastError = rc; ready = rc == 0;
}
static void onReset(int reason) {
  ready = scanning = beacon = false; lastError = reason;
}
static void hostTask(void *) {
  nimble_port_run(); nimble_port_freertos_deinit();
}
static bool initialize() {
  if (started) return ready;
  if (ESP.getFreeHeap() < 80000) { lastError = -1; return false; }
  int rc = nimble_port_init(); lastError = rc;
  if (rc) return false;
  started = true;
  ble_hs_cfg.sync_cb = onSync;
  ble_hs_cfg.reset_cb = onReset;
  nimble_port_freertos_init(hostTask);
  // Host synchronization is asynchronous. The UI retries after status refresh.
  return ready;
}
static void stop() {
  if (!ready) return;
  if (ble_gap_disc_active()) ble_gap_disc_cancel();
  if (ble_gap_adv_active()) ble_gap_adv_stop();
  scanning = beacon = false;
}
static int scan() {
  if (!initialize()) return -2;
  if (scanning || beacon) return -3;
  uint32_t now = millis();
  if (scannedBefore && now - lastScan < 10000) return -4;
  portENTER_CRITICAL(&mux); count = dropped = 0; portEXIT_CRITICAL(&mux);
  ble_gap_disc_params params{};
  params.passive = 1; params.itvl = 160; params.window = 32; params.filter_duplicates = 1;
  scanning = true;
  int rc = ble_gap_disc(ownType, 5000, &params, onEvent, nullptr);
  if (rc) scanning = false;
  else { lastScan = now; scannedBefore = true; }
  lastError = rc; return rc;
}
static int advertise(const char *name) {
  if (!initialize()) return -2;
  if (scanning || beacon) return -3;
  ble_hs_adv_fields fields{};
  fields.flags = BLE_HS_ADV_F_DISC_GEN | BLE_HS_ADV_F_BREDR_UNSUP;
  fields.name = (const uint8_t *)name;
  fields.name_len = strlen(name); fields.name_is_complete = 1;
  int rc = ble_gap_adv_set_fields(&fields);
  if (!rc) {
    ble_gap_adv_params params{};
    params.conn_mode = BLE_GAP_CONN_MODE_NON; params.disc_mode = BLE_GAP_DISC_MODE_GEN;
    params.itvl_min = 800; params.itvl_max = 960; // 500-600 ms, one named beacon
    beacon = true;
    rc = ble_gap_adv_start(ownType, nullptr, 60000, &params, onEvent, nullptr);
    if (rc) beacon = false;
  }
  if (!rc) strlcpy(beaconName, name, sizeof(beaconName));
  lastError = rc; return rc;
}
static void status(JsonDocument &json) {
  Device copy[20]; unsigned n, overflow;
  portENTER_CRITICAL(&mux);
  n = count; overflow = dropped; memcpy(copy, devices, sizeof(copy));
  portEXIT_CRITICAL(&mux);
  json["ready"] = ready.load(); json["initialized"] = started;
  json["scanning"] = scanning.load(); json["beacon"] = beacon.load();
  json["error"] = lastError.load(); json["dropped"] = overflow;
  json["name"] = beaconName;
  auto list = json["devices"].to<JsonArray>();
  for (unsigned i = 0; i < n; ++i) {
    auto item = list.add<JsonObject>(); char address[18];
    const auto &d = copy[i];
    snprintf(address, sizeof(address), "%02x:%02x:%02x:%02x:%02x:%02x", d.address[5], d.address[4], d.address[3], d.address[2], d.address[1], d.address[0]);
    item["address"] = address; item["type"] = d.type;
    item["name"] = d.name; item["rssi"] = d.rssi;
  }
}
}
