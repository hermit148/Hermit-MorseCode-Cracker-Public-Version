#pragma once
#include <stdint.h>
namespace hmcwifi {
enum class State:uint8_t {NotConfigured,Disconnected,Connecting,Connected,Failed};
enum class Error:uint8_t {None,NotFound,Authentication,Timeout,Lost,PasswordRequired,Unsupported};
constexpr const char *name(State s){return s==State::Connected?"connected":s==State::Connecting?"connecting":s==State::Failed?"failed":s==State::NotConfigured?"not-configured":"disconnected";}
constexpr const char *label(State s){return s==State::Connected?"CONNECTED":s==State::Connecting?"CONNECTING":s==State::Failed?"NOT CONNECTED":s==State::NotConfigured?"NOT CONFIGURED":"DISCONNECTED";}
constexpr const char *message(Error e){return e==Error::NotFound?"Network not found":e==Error::Authentication?"Check Wi-Fi password":e==Error::Timeout?"Connection timed out":e==Error::Lost?"Connection lost":e==Error::PasswordRequired?"Password required":e==Error::Unsupported?"Unsupported security":"";}
// ESP-IDF Wi-Fi disconnect reason codes. A reason is advisory; DHCP/IP is the
// success criterion. Never label an unproven connection as internet access.
constexpr Error reason(unsigned r){return r==201||r==210||r==211||r==212?Error::NotFound:r==15||r==16||r==23||r==202||r==204?Error::Authentication:Error::Timeout;}
struct Link {
 State state=State::NotConfigured;Error error=Error::None;uint32_t started=0;
 constexpr void begin(uint32_t now){state=State::Connecting;error=Error::None;started=now;}
 constexpr void fail(Error e){state=State::Failed;error=e;}
 constexpr void tick(bool connected,unsigned why,uint32_t now){
  if(connected){state=State::Connected;error=Error::None;}
  else if(state==State::Connected)fail(Error::Lost);
  else if(state==State::Connecting&&uint32_t(now-started)>=20000)fail(reason(why));
 }
};
struct Network {char ssid[33]={};int rssi=-127;uint8_t channel=0;bool secure=false,supported=true;};
struct Cache {
 static constexpr unsigned capacity=16;Network items[capacity]={};unsigned count=0;
 constexpr void clear(){count=0;for(auto &n:items)n=Network{};}
 constexpr bool same(const char *a,const char *b){for(unsigned i=0;i<33;++i){if(a[i]!=b[i])return false;if(!a[i])return true;}return true;}
 constexpr void add(const char *ssid,int rssi,uint8_t channel,bool secure,bool supported){
  unsigned length=0;while(ssid[length]){if(++length>32)return;}if(!length)return;
  unsigned slot=0;for(;slot<count;++slot)if(same(items[slot].ssid,ssid))break;
  if(slot<count&&items[slot].rssi>=rssi)return;
  if(slot==count){if(count<capacity)++count;else{slot=0;for(unsigned i=1;i<count;++i)if(items[i].rssi<items[slot].rssi)slot=i;if(rssi<=items[slot].rssi)return;}}
  auto &n=items[slot];n=Network{};for(unsigned i=0;i<length;++i)n.ssid[i]=ssid[i];n.rssi=rssi;n.channel=channel;n.secure=secure;n.supported=supported;
 }
 constexpr void sort(){for(unsigned i=0;i<count;++i)for(unsigned j=i+1;j<count;++j)if(items[j].rssi>items[i].rssi){auto n=items[i];items[i]=items[j];items[j]=n;}}
};
}
