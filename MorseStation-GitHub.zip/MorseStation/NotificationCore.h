#pragma once
#include <stddef.h>
namespace hmcnotify {
constexpr bool webhookValid(const char *s){
  const char *prefix="https://discord.com/api/webhooks/";unsigned i=0;
  for(;prefix[i];++i)if(s[i]!=prefix[i])return false;
  unsigned digits=0;while(s[i]>='0'&&s[i]<='9'){++i;++digits;if(digits>22)return false;}
  if(digits<15||s[i++]!='/')return false;
  unsigned token=0;while(s[i]){char c=s[i++];if(!((c>='A'&&c<='Z')||(c>='a'&&c<='z')||(c>='0'&&c<='9')||c=='_'||c=='-'))return false;if(++token>160||i>240)return false;}
  return token>=40;
}
constexpr const char *state(bool configured,bool partial=false){return configured?"CONFIGURED":partial?"PARTLY CONFIGURED":"NOT CONFIGURED";}
}
