#pragma once
// Set to 1 after wiring the optional INMP441; leave disabled until the microphone is wired.
#ifndef ENABLE_I2S_MIC
#define ENABLE_I2S_MIC 0
#endif
// Set to 1 only for Wokwi. It connects to Wokwi-GUEST without a password.
#ifndef WOKWI_BUILD
#define WOKWI_BUILD 0
#endif
// Your five switches connect directly to GPIO by default. Set to 1 only when
// using an MCP23017 to free pins for the optional I2S microphone.
#ifndef BUTTONS_USE_MCP23017
#define BUTTONS_USE_MCP23017 0
#endif
// Explicit opt-in for INMP441 + five direct buttons. Requires a physical
// 10k pullup from GPIO2 to 3V3; the microphone's SCK pin is an INPUT.
#ifndef MIC_DIRECT_BOOT_CLOCK
#define MIC_DIRECT_BOOT_CLOCK 0
#endif
constexpr int PIN_BUZZER = 6;
constexpr int PIN_SDA = 5, PIN_SCL = 0;
constexpr int NAV_BUTTON_PINS[5] = {3,4,7,10,1}; // UP, DOWN, LEFT, RIGHT, SELECT
// Native USB keeps GPIO18/19. Optional microphone uses the free UART pins.
#if MIC_DIRECT_BOOT_CLOCK
constexpr int PIN_MIC_BCLK = 2, PIN_MIC_WS = 21, PIN_MIC_DATA = 20;
#else
constexpr int PIN_MIC_BCLK = 20, PIN_MIC_WS = 21, PIN_MIC_DATA = 1;
#endif
constexpr unsigned NAV_I2C_ADDRESS = 0x20; // MCP23017, A0/A1/A2 grounded
constexpr bool validPinPlan() {
  const int pins[] = {PIN_BUZZER,PIN_SDA,PIN_SCL,
#if !BUTTONS_USE_MCP23017
    NAV_BUTTON_PINS[0],NAV_BUTTON_PINS[1],NAV_BUTTON_PINS[2],NAV_BUTTON_PINS[3],NAV_BUTTON_PINS[4],
#endif
#if ENABLE_I2S_MIC
    PIN_MIC_BCLK,PIN_MIC_WS,PIN_MIC_DATA,
#endif
  };
  for(unsigned i=0;i<sizeof(pins)/sizeof(pins[0]);++i) {
    if(pins[i]<0||pins[i]>21||pins[i]==8||pins[i]==9||(pins[i]>=11&&pins[i]<=19))return false;
    if(pins[i]==2 && !(ENABLE_I2S_MIC && MIC_DIRECT_BOOT_CLOCK && !BUTTONS_USE_MCP23017 && pins[i]==PIN_MIC_BCLK))return false;
    for(unsigned j=0;j<i;++j)if(pins[i]==pins[j])return false;
  }
  return NAV_I2C_ADDRESS>=0x20&&NAV_I2C_ADDRESS<=0x27;
}
static_assert(validPinPlan(),"Pin collision or reserved/boot/USB pin in hardware plan");
#if MIC_DIRECT_BOOT_CLOCK && (!ENABLE_I2S_MIC || BUTTONS_USE_MCP23017)
#error "MIC_DIRECT_BOOT_CLOCK requires ENABLE_I2S_MIC=1 and BUTTONS_USE_MCP23017=0"
#endif
#if ENABLE_I2S_MIC && !BUTTONS_USE_MCP23017 && !MIC_DIRECT_BOOT_CLOCK
#error "I2S microphone needs BUTTONS_USE_MCP23017=1 or explicit MIC_DIRECT_BOOT_CLOCK=1 with GPIO2 pullup"
#endif
#if ENABLE_I2S_MIC && defined(ARDUINO_ARCH_ESP32) && !ARDUINO_USB_CDC_ON_BOOT
#error "Microphone uses UART pins 20/21: keep native USB CDC enabled on the C3 SuperMini"
#endif
