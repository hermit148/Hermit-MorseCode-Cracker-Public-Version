#pragma once
#include <stdint.h>
namespace hmcnav {
enum class Button:uint8_t {Up,Down,Left,Right,Select};
enum class Edge:uint8_t {None,Press,Release,Hold,Repeat};
struct Event {Button button=Button::Up;Edge edge=Edge::None;bool held=false;};
enum class Screen:uint8_t {Compose,Menu,Receive,Presets,Device,Network,Ble,Post,SendMenu,ReceiveMenu,Tools,System,Setup,SignalSetup,DisplaySetup,InputSetup,Adjust,Confirm,About,Connections,WifiSetup,TelegramSetup,TelegramOptions,DiscordSetup,DiscordOptions,Tests,BuzzerTest,MicTest,WifiManual,WifiScan,WifiStatus,Count};
enum class Action:uint8_t {None,Send,Finish,ClearRx,ToggleMode,LoadPreset,PlayPreset,EditSpeed,EditTone,EditContrast,EditThreshold,ToggleAuto,ToggleDim,SaveSetting,BleScan,BleBeacon,BleStop,EditWifiSsid,EditWifiPass,EditTgToken,EditTgChat,EditDiscord,SaveText,ToggleTgTx,ToggleTgRx,ToggleDcTx,ToggleDcRx,ClearTg,ClearDc,ToggleBootSound,TestBuzzer,WifiScan,WifiChoose,WifiRetry};
enum class Field:uint8_t {Message,WifiSsid,WifiPass,TgToken,TgChat,DiscordUrl};
enum class Setting:uint8_t {Speed,Tone,Contrast,Threshold};
enum class Notice:uint8_t {Ready,Full,Empty,Sent,Stopped,Busy,Cleared,Loaded,Unavailable,Failed,Saved,Starting,Cooldown,Invalid};
constexpr const char *noticeText(Notice n){return n==Notice::Full?"DRAFT FULL":n==Notice::Empty?"MESSAGE EMPTY":n==Notice::Sent?"SENDING":n==Notice::Stopped?"STOPPED":n==Notice::Busy?"DEVICE BUSY":n==Notice::Cleared?"CLEARED":n==Notice::Loaded?"PRESET LOADED":n==Notice::Unavailable?"NOT AVAILABLE":n==Notice::Failed?"TRY AGAIN":n==Notice::Saved?"SAVED":n==Notice::Starting?"STARTING BLE":n==Notice::Cooldown?"WAIT 10 SECONDS":n==Notice::Invalid?"INVALID VALUE":"READY";}
constexpr char character(unsigned i){return i<26?char('A'+i):i<36?char('0'+i-26):' ';}

constexpr const char *screenName(Screen s){return s==Screen::Compose?"compose":s==Screen::Menu?"menu":s==Screen::Receive?"receive":s==Screen::Presets?"presets":s==Screen::Device?"device":s==Screen::Network?"network":s==Screen::Ble?"ble":s==Screen::Post?"post":s==Screen::SendMenu?"send":s==Screen::ReceiveMenu?"receive-options":s==Screen::Tools?"tools":s==Screen::System?"system":s==Screen::Setup?"setup":s==Screen::SignalSetup?"signal-settings":s==Screen::DisplaySetup?"display-settings":s==Screen::InputSetup?"input-settings":s==Screen::About?"about":s==Screen::Adjust?"adjust":s==Screen::Connections?"connections":s==Screen::WifiSetup?"wifi-settings":s==Screen::TelegramSetup?"telegram-settings":s==Screen::TelegramOptions?"telegram-options":s==Screen::DiscordSetup?"discord-settings":s==Screen::DiscordOptions?"discord-options":s==Screen::Tests?"tests":s==Screen::BuzzerTest?"buzzer-test":s==Screen::MicTest?"mic-test":s==Screen::WifiManual?"wifi-manual":s==Screen::WifiScan?"wifi-scan":s==Screen::WifiStatus?"wifi-status":"confirm";}
constexpr const char *title(Screen s){return s==Screen::Menu?"MORSE CRACKER":s==Screen::SendMenu?"SEND":s==Screen::ReceiveMenu?"RECEIVE":s==Screen::Tools?"TOOLS":s==Screen::System?"SYSTEM":s==Screen::Setup?"SETUP":s==Screen::SignalSetup?"SIGNAL":s==Screen::DisplaySetup?"DISPLAY":s==Screen::InputSetup?"INPUT":s==Screen::Ble?"BLUETOOTH":s==Screen::Presets?"SAVED MESSAGES":s==Screen::Connections?"CONNECTIONS":s==Screen::WifiSetup?"WI-FI SETUP":s==Screen::WifiManual?"MANUAL WI-FI":s==Screen::TelegramSetup?"TELEGRAM":s==Screen::TelegramOptions?"TELEGRAM OPTIONS":s==Screen::DiscordSetup?"DISCORD":s==Screen::DiscordOptions?"DISCORD OPTIONS":s==Screen::Tests?"HARDWARE TESTS":"HOME";}
constexpr unsigned menuCount(Screen s){return 4;}
constexpr const char *menuLabel(Screen s,unsigned i){
  if(i==menuCount(s)-1)return "Back";
  if(s==Screen::SendMenu)return i==0?"Write text":i==1?"Saved msgs":"Clear draft";
  if(s==Screen::ReceiveMenu)return i==0?"Listen":i==1?"Finish msg":"Clear input";
  if(s==Screen::Tools)return i==0?"Wi-Fi":i==1?"Bluetooth":"System";
  if(s==Screen::System)return i==0?"Tests":i==1?"Device info":"About";
  if(s==Screen::Setup)return i==0?"Morse":i==1?"Display":"Connections";
  if(s==Screen::SignalSetup)return i==0?"Speed":i==1?"Tone":"Receive";
  if(s==Screen::DisplaySetup)return i==0?"Brightness":i==1?"Auto dim":"Boot sound";
  if(s==Screen::InputSetup)return i==0?"Auto speed":i==1?"Source":"Mic level";
  if(s==Screen::Ble)return i==0?"Scan 5 sec":i==1?"Beacon 60s":"Stop radio";
  if(s==Screen::Connections)return i==0?"Wi-Fi":i==1?"Telegram":"Discord";
  if(s==Screen::WifiSetup)return i==0?"Scan Wi-Fi":i==1?"Manual setup":"Link status";
  if(s==Screen::WifiManual)return i==0?"SSID":i==1?"Password":"AP details";
  if(s==Screen::TelegramSetup)return i==0?"Bot token":i==1?"Chat ID":"Options";
  if(s==Screen::DiscordSetup)return i==0?"Webhook URL":i==1?"Options":"Clear setup";
  if(s==Screen::TelegramOptions||s==Screen::DiscordOptions)return i==0?"Forward TX":i==1?"Forward RX":"Clear setup";
  if(s==Screen::Tests)return i==0?"POST report":i==1?"Buzzer test":"Mic test";
  return "Back";
}
constexpr const char *homeLabel(unsigned i){return i==0?"SEND":i==1?"RECEIVE":i==2?"TOOLS":"SETUP";}
constexpr Screen homeScreen(unsigned i){return i==0?Screen::SendMenu:i==1?Screen::ReceiveMenu:i==2?Screen::Tools:Screen::Setup;}
constexpr Screen viewScreen(unsigned i){return i==1?Screen::Receive:i==2?Screen::Device:i==3?Screen::Network:i==4?Screen::Ble:i==5?Screen::Post:i==6?Screen::Compose:Screen::Menu;}
constexpr bool isList(Screen s){return s==Screen::SendMenu||s==Screen::ReceiveMenu||s==Screen::Tools||s==Screen::System||s==Screen::Setup||s==Screen::SignalSetup||s==Screen::DisplaySetup||s==Screen::InputSetup||s==Screen::Ble||s==Screen::Connections||s==Screen::WifiSetup||s==Screen::WifiManual||s==Screen::TelegramSetup||s==Screen::TelegramOptions||s==Screen::DiscordSetup||s==Screen::DiscordOptions||s==Screen::Tests;}
class KeyState {
  bool candidate=false,down=false,longDone=false;uint32_t changed=0,pressed=0,repeated=0;
public:
  constexpr bool isDown()const{return down;}
  constexpr Event tick(Button b,bool raw,uint32_t now){
    if(raw!=candidate){candidate=raw;changed=now;}
    if(candidate!=down&&now-changed>=15){down=candidate;if(down){pressed=repeated=now;longDone=false;return {b,Edge::Press,false};}return {b,Edge::Release,longDone};}
    if(down&&b==Button::Select&&!longDone&&now-pressed>=800){longDone=true;return {b,Edge::Hold,true};}
    if(down&&b!=Button::Select&&now-pressed>=400&&now-repeated>=110){repeated=now;return {b,Edge::Repeat,false};}return {};
  }
};
struct Keyboard {
  char text[121]={},entry[257]={};unsigned length=0,entryLength=0,cursor=0,menu=0,preset=0,presetPage=0,postPage=0,keyPage=0,clearTarget=0;Field field=Field::Message;bool upper=true;uint32_t lastTypedAt=0;
  Screen screen=Screen::Menu;unsigned wifiCount=0;
  struct Parent{Screen screen=Screen::Menu;unsigned menu=0;};Parent parents[8]={};unsigned depth=0;
  Notice notice=Notice::Ready;bool active=false;uint32_t changedAt=0;
  Setting setting=Setting::Speed;int editValue=12,editMin=5,editMax=30,editStep=1;bool confirmRx=false;
  constexpr bool setText(const char *s){
    unsigned n=0;while(s[n]){if(n==120)return false;char c=s[n];if(c>='a'&&c<='z')c-=32;
      bool allowed=c==' '||(c>='A'&&c<='Z')||(c>='0'&&c<='9');const char *punct=".,?/=+-@!():'";
      for(unsigned j=0;punct[j];++j)if(c==punct[j])allowed=true;if(!allowed)return false;++n;}
    for(unsigned i=0;i<n;++i)text[i]=s[i]>='a'&&s[i]<='z'?s[i]-32:s[i];length=n;text[n]=0;return true;
  }
  constexpr void open(Screen s){
    if(s==screen)return;if(depth==8){notice=Notice::Busy;return;}parents[depth++]={screen,menu};screen=s;menu=0;
    if(s==Screen::Compose&&cursor==32)cursor=0;
    if(s==Screen::Presets){menu=preset;presetPage=preset/3;}
  }
  constexpr void back(){if(screen==Screen::Compose&&field!=Field::Message){for(auto &c:entry)c=0;entryLength=0;field=Field::Message;}if(depth){auto p=parents[--depth];screen=p.screen;menu=p.menu;}else if(screen!=Screen::Menu){screen=Screen::Menu;menu=0;}notice=Notice::Ready;}
  constexpr void go(Screen s){
    screen=Screen::Menu;menu=0;depth=0;postPage=0;field=Field::Message;entryLength=0;for(auto &c:entry)c=0;
    if(s==Screen::Menu)return;
    if(s==Screen::Compose||s==Screen::Presets||s==Screen::SendMenu){open(Screen::SendMenu);if(s!=Screen::SendMenu){menu=s==Screen::Presets?1:0;open(s);}return;}
    if(s==Screen::Receive||s==Screen::ReceiveMenu){menu=1;open(Screen::ReceiveMenu);if(s==Screen::Receive)open(s);return;}
    if(s==Screen::WifiScan||s==Screen::WifiStatus||s==Screen::WifiManual){go(Screen::WifiSetup);menu=s==Screen::WifiScan?0:s==Screen::WifiManual?1:2;open(s);return;}
    if(s==Screen::Setup||s==Screen::SignalSetup||s==Screen::DisplaySetup||s==Screen::InputSetup||s==Screen::Connections||s==Screen::WifiSetup||s==Screen::TelegramSetup||s==Screen::TelegramOptions||s==Screen::DiscordSetup||s==Screen::DiscordOptions){menu=3;open(Screen::Setup);if(s!=Screen::Setup){menu=s==Screen::DisplaySetup?1:s==Screen::InputSetup||s==Screen::SignalSetup?0:2;
      if(s==Screen::InputSetup){open(Screen::SignalSetup);menu=2;open(s);}
      else if(s==Screen::Connections||s==Screen::WifiSetup||s==Screen::TelegramSetup||s==Screen::TelegramOptions||s==Screen::DiscordSetup||s==Screen::DiscordOptions){open(Screen::Connections);if(s!=Screen::Connections){menu=s==Screen::WifiSetup?0:s==Screen::TelegramSetup||s==Screen::TelegramOptions?1:2;open(s==Screen::TelegramOptions?Screen::TelegramSetup:s==Screen::DiscordOptions?Screen::DiscordSetup:s);if(s==Screen::TelegramOptions||s==Screen::DiscordOptions){menu=s==Screen::TelegramOptions?2:1;open(s);}}}
      else open(s);}return;}
    menu=2;open(Screen::Tools);if(s==Screen::Tools)return;
    if(s==Screen::Network||s==Screen::Ble){menu=s==Screen::Ble?1:0;open(s);return;}
    menu=2;open(Screen::System);if(s!=Screen::System){menu=s==Screen::Device?1:s==Screen::About?2:0;if(s==Screen::Post||s==Screen::Tests||s==Screen::BuzzerTest||s==Screen::MicTest){open(Screen::Tests);if(s!=Screen::Tests){menu=s==Screen::BuzzerTest?1:s==Screen::MicTest?2:0;open(s);}}else open(s);}
  }
  struct KeyText{char text[4]={};};
  constexpr unsigned limit()const{return field==Field::Message?120:field==Field::WifiSsid?32:field==Field::WifiPass?63:field==Field::TgToken?120:field==Field::TgChat?24:240;}
  constexpr bool secret()const{return field==Field::WifiPass||field==Field::TgToken||field==Field::DiscordUrl;}
  constexpr unsigned typedLength()const{return field==Field::Message?length:entryLength;}
  constexpr const char *typedText()const{return field==Field::Message?text:entry;}
  constexpr const char *fieldTitle()const{return field==Field::Message?"WRITE":field==Field::WifiSsid?"WI-FI SSID":field==Field::WifiPass?"WI-FI PASS":field==Field::TgToken?"TG TOKEN":field==Field::TgChat?"TG CHAT ID":"DISCORD URL";}
  constexpr void beginEntry(Field f,const char *value){field=f;entryLength=0;for(auto &c:entry)c=0;if(f!=Field::Message)while(value[entryLength]&&entryLength<limit()){entry[entryLength]=value[entryLength];++entryLength;}cursor=0;keyPage=f==Field::TgChat||f==Field::TgToken?1:0;upper=f!=Field::DiscordUrl&&f!=Field::WifiPass;lastTypedAt=0;open(Screen::Compose);}
  constexpr KeyText caption(unsigned i)const{
    KeyText k;
    if(i>=27){const char *s=i==27?"Aa":i==28?"123":i==29?"DEL":i==30?"CLR":i==31?(field==Field::Message?"SEND":"SAVE"):"BACK";for(unsigned j=0;j<3&&s[j];++j)k.text[j]=s[j];return k;}
    if(i==26){k.text[0]='S';k.text[1]='P';return k;}
    if(keyPage==0)k.text[0]=char((upper?'A':'a')+i);
    else if(field==Field::Message){const char *s="0123456789.,?/=+-@!():'";if(i<23)k.text[0]=s[i];else{const char *q=i==23?"CQ":i==24?"73":"HI";k.text[0]=q[0];k.text[1]=q[1];}}
    else{const char *common=".,?/:;@!#-_+=()&";const char extra[]={34,39,92,91,93,123,125,60,62,94,126,124,36,37,42,96};k.text[0]=i<10?char('0'+i):keyPage==1?common[i-10]:extra[i-10];}
    return k;
  }
  constexpr void confirm(unsigned target){clearTarget=target;confirmRx=target==1;open(Screen::Confirm);menu=1;}
  constexpr Action choose(unsigned i){
    if(i>=33)return Action::None;cursor=i;notice=Notice::Ready;
    if(i<27){KeyText key=caption(i);if(i==26){key.text[0]=' ';key.text[1]=0;}unsigned n=key.text[1]?2:1;if(typedLength()+n>limit()){notice=Notice::Full;return Action::None;}char *buf=field==Field::Message?text:entry;unsigned &len=field==Field::Message?length:entryLength;for(unsigned j=0;j<n;++j)buf[len++]=key.text[j];buf[len]=0;lastTypedAt=changedAt;}
    else if(i==27){upper=!upper;keyPage=0;}
    else if(i==28)keyPage=(keyPage+1)%(field==Field::Message?2:3);
    else if(i==29){unsigned &len=field==Field::Message?length:entryLength;char *buf=field==Field::Message?text:entry;if(len)buf[--len]=0;lastTypedAt=0;}
    else if(i==30)confirm(2);
    else if(i==31){if(field==Field::Message){if(!length)notice=Notice::Empty;return Action::Send;}return Action::SaveText;}
    else back();return Action::None;
  }
  constexpr Action activate(){
    Screen s=screen;unsigned i=menu;
    if(i==menuCount(s)-1){back();return Action::None;}
    if(s==Screen::SendMenu){if(i==0){field=Field::Message;open(Screen::Compose);}else if(i==1){open(Screen::Presets);menu=preset;presetPage=preset/3;}else{confirm(0);}}
    else if(s==Screen::ReceiveMenu){if(i==0)open(Screen::Receive);else if(i==1)return Action::Finish;else{confirm(1);}}
    else if(s==Screen::Tools)open(i==0?Screen::Network:i==1?Screen::Ble:Screen::System);
    else if(s==Screen::System)open(i==0?Screen::Tests:i==1?Screen::Device:Screen::About);
    else if(s==Screen::Setup)open(i==0?Screen::SignalSetup:i==1?Screen::DisplaySetup:Screen::Connections);
    else if(s==Screen::SignalSetup){if(i==2)open(Screen::InputSetup);else return i==0?Action::EditSpeed:Action::EditTone;}
    else if(s==Screen::DisplaySetup)return i==0?Action::EditContrast:i==1?Action::ToggleDim:Action::ToggleBootSound;
    else if(s==Screen::InputSetup)return i==0?Action::ToggleAuto:i==1?Action::ToggleMode:Action::EditThreshold;
    else if(s==Screen::Ble)return i==0?Action::BleScan:i==1?Action::BleBeacon:Action::BleStop;
    else if(s==Screen::Connections)open(i==0?Screen::WifiSetup:i==1?Screen::TelegramSetup:Screen::DiscordSetup);
    else if(s==Screen::WifiSetup){if(i==0){open(Screen::WifiScan);return Action::WifiScan;}open(i==1?Screen::WifiManual:Screen::WifiStatus);}
    else if(s==Screen::WifiManual){if(i==2)open(Screen::Network);else return i==0?Action::EditWifiSsid:Action::EditWifiPass;}
    else if(s==Screen::TelegramSetup){if(i==2)open(Screen::TelegramOptions);else return i==0?Action::EditTgToken:Action::EditTgChat;}
    else if(s==Screen::DiscordSetup){if(i==0)return Action::EditDiscord;else if(i==1)open(Screen::DiscordOptions);else confirm(4);}
    else if(s==Screen::TelegramOptions||s==Screen::DiscordOptions){if(i==2)confirm(s==Screen::TelegramOptions?3:4);else return s==Screen::TelegramOptions?(i==0?Action::ToggleTgTx:Action::ToggleTgRx):(i==0?Action::ToggleDcTx:Action::ToggleDcRx);}
    else if(s==Screen::Tests){open(i==0?Screen::Post:i==1?Screen::BuzzerTest:Screen::MicTest);if(i==1)return Action::TestBuzzer;}
    return Action::None;
  }
  constexpr Action input(Event e,uint32_t now){
    if(e.edge==Edge::None)return Action::None;active=true;changedAt=now;
    if(e.edge==Edge::Hold&&e.button==Button::Select){if(screen!=Screen::Receive)back();return Action::None;}
    bool select=e.button==Button::Select&&e.edge==Edge::Release&&!e.held;
    bool arrow=e.button!=Button::Select&&(e.edge==Edge::Press||e.edge==Edge::Repeat);
    if(!select&&!arrow)return Action::None;
    if(e.edge==Edge::Repeat&&screen!=Screen::Compose&&!((isList(screen)||screen==Screen::Presets||screen==Screen::WifiScan||screen==Screen::Adjust||screen==Screen::Post)&&(e.button==Button::Up||e.button==Button::Down)))return Action::None;
    notice=Notice::Ready;
    if(screen==Screen::Compose){if(select)return choose(cursor);
      if(cursor<27){unsigned row=cursor/9,col=cursor%9;if(e.button==Button::Left)col=(col+8)%9;if(e.button==Button::Right)col=(col+1)%9;
        if(e.button==Button::Up){if(row==0){cursor=27+col*6/9;return Action::None;}--row;}
        if(e.button==Button::Down){if(row==2){cursor=27+col*6/9;return Action::None;}++row;}cursor=row*9+col;
      }else{unsigned col=cursor-27;if(e.button==Button::Left)cursor=27+(col+5)%6;else if(e.button==Button::Right)cursor=27+(col+1)%6;else cursor=(e.button==Button::Up?18:0)+(col*2+1)*9/12;}
    }else if(screen==Screen::Menu){if(select)open(homeScreen(menu));else if(e.button==Button::Left||e.button==Button::Right)menu^=1;else menu^=2;}
    else if(screen==Screen::Receive){if(e.button==Button::Left&&arrow)back();else if(e.button==Button::Right&&arrow)return Action::Finish;else if(e.button==Button::Down&&arrow){confirmRx=true;open(Screen::Confirm);menu=1;}}
    else if(screen==Screen::Presets){
      if(e.button==Button::Left&&arrow){back();return Action::None;}
      if(select&&menu==6){back();return Action::None;}
      if(menu<6){preset=menu;presetPage=preset/3;if(select)return Action::LoadPreset;if(e.button==Button::Right&&arrow)return Action::PlayPreset;}
      if(e.button==Button::Up)menu=(menu+6)%7;else if(e.button==Button::Down)menu=(menu+1)%7;
      if(menu<6){preset=menu;presetPage=preset/3;}
    }else if(screen==Screen::WifiScan){
      unsigned count=wifiCount+2;
      if(e.button==Button::Left){back();return Action::None;}
      if(e.button==Button::Up)menu=(menu+count-1)%count;else if(e.button==Button::Down)menu=(menu+1)%count;
      if(select||e.button==Button::Right){if(menu==wifiCount+1)back();else return menu==wifiCount?Action::WifiScan:Action::WifiChoose;}
    }else if(screen==Screen::WifiStatus){if(e.button==Button::Right)return Action::WifiRetry;if(select||e.button==Button::Left)back();}
    else if(screen==Screen::Adjust){
      if(e.button==Button::Left&&arrow){back();return Action::None;}
      if(e.button==Button::Up){editValue+=editStep;if(editValue>editMax)editValue=editMax;}
      else if(e.button==Button::Down){editValue-=editStep;if(editValue<editMin)editValue=editMin;}
      else if(e.button==Button::Right)menu^=1;
      if(select){if(menu)back();else return Action::SaveSetting;}
    }else if(screen==Screen::Confirm){
      if(e.button==Button::Left){back();return Action::None;}
      if(arrow)menu^=1;if(select){bool clear=menu==0;unsigned target=clearTarget;back();if(clear){if(target==1)return Action::ClearRx;if(target==3)return Action::ClearTg;if(target==4)return Action::ClearDc;if(target==2&&field!=Field::Message){for(auto &c:entry)c=0;entryLength=0;}else{length=0;text[0]=0;}notice=Notice::Cleared;}}
    }else if(screen==Screen::Post){if(e.button==Button::Up)postPage=(postPage+4)%5;else if(e.button==Button::Down||e.button==Button::Right)postPage=(postPage+1)%5;else back();}
    else if(screen==Screen::BuzzerTest){if(select)return Action::TestBuzzer;if(e.button==Button::Left)back();}
    else if(isList(screen)){if(e.button==Button::Left){back();return Action::None;}if(select||e.button==Button::Right)return activate();unsigned count=menuCount(screen);if(e.button==Button::Up)menu=(menu+count-1)%count;else if(e.button==Button::Down)menu=(menu+1)%count;}
    else if(select||arrow)back();return Action::None;
  }
};
}
