#pragma once
#include "WifiCore.h"
#include <esp_wifi.h>
// All cache, scan and link transitions belong to the main loop. The SDK event
// task writes only an atomic reason code; it never touches config or the OLED.
hmcwifi::Link wifiLink;
hmcwifi::Cache wifiNetworks;
std::atomic<unsigned> wifiDisconnectReason{0};
bool wifiScanning=false,wifiScanDone=false,wifiScanFailed=false,wifiBeginPending=false,wifiScannedBefore=false;
uint32_t wifiScanStarted=0,wifiScannedAt=0,wifiRetryAt=0,wifiBeginAt=0;
String wifiDraftSsid;
bool wifiDraftActive=false;

bool wifiConnected(){return !wifiBeginPending&&WiFi.status()==WL_CONNECTED;}
void cancelWifiScan(){if(wifiScanning)esp_wifi_scan_stop();WiFi.scanDelete();wifiScanning=false;}
void requestWifiConnection(){
 cancelWifiScan();wifiDisconnectReason=0;wifiRetryAt=wifiBeginAt=millis();
 bool configured;{Guard g(configLock);configured=cfg.ssid.length()>0;}
#if WOKWI_BUILD
 configured=true;
#endif
 wifiBeginPending=configured;wifiLink.error=hmcwifi::Error::None;
 if(configured)wifiLink.begin(millis());else{WiFi.disconnect(false,false);wifiLink.state=hmcwifi::State::NotConfigured;}
}
int startWifiScan(){
 uint32_t now=millis();if(wifiScanning)return -1;
 if(wifiScannedBefore&&uint32_t(now-wifiScanStarted)<10000)return -2;
 if(wifiBeginPending||wifiLink.state==hmcwifi::State::Connecting){wifiBeginPending=false;WiFi.disconnect(false,false);wifiLink.state=hmcwifi::State::Disconnected;wifiLink.error=hmcwifi::Error::None;}
 wifiRetryAt=now;WiFi.scanDelete();wifiScanDone=wifiScanFailed=false;wifiScanStarted=now;
 WiFi.setScanTimeout(10000);
 int rc=WiFi.scanNetworks(true,false,false,120);
 if(rc==WIFI_SCAN_FAILED){wifiScanFailed=true;return -3;}
 wifiScannedBefore=true;wifiScanning=true;wifiNetworks.clear();keyboard.wifiCount=0;return 0;
}
void wifiSummary(JsonObject d){
 bool connected=wifiConnected();d["connected"]=connected;d["state"]=hmcwifi::name(wifiLink.state);
 d["label"]=hmcwifi::label(wifiLink.state);d["reason"]=hmcwifi::message(wifiLink.error);
 d["clockReady"]=time(nullptr)>=1700000000;d["ip"]=connected?WiFi.localIP().toString():String("");
 d["rssi"]=connected?WiFi.RSSI():0;d["apIp"]=WiFi.softAPIP().toString();
 {Guard g(configLock);d["ssid"]=cfg.ssid;d["configured"]=cfg.ssid.length()>0;d["passwordSet"]=cfg.pass.length()>0;}
}
void printNetworkReport(){
 Config c;{Guard g(configLock);c=cfg;}
 Serial.printf("[NET] Wi-Fi %s / %s / password %s / IP %s / clock %s\n",hmcwifi::label(wifiLink.state),hmcwifi::message(wifiLink.error),c.pass.length()?"SET":"EMPTY",wifiConnected()?WiFi.localIP().toString().c_str():"none",time(nullptr)>=1700000000?"READY":"WAIT");
 Serial.printf("[NET] Telegram %s / TX %s / RX %s / delivery state %d\n",tokenValid(c.bot)&&chatValid(c.chat)?"CONFIGURED":"NOT CONFIGURED",c.forwardTx?"ON":"OFF",c.forwardRx?"ON":"OFF",telegramStatus.load());
 Serial.printf("[NET] Scan %s / %u networks (no credentials printed)\n",wifiScanning?"RUNNING":wifiScanFailed?"FAILED":wifiScanDone?"READY":"IDLE",wifiNetworks.count);
}
void serviceWifi(uint32_t now){
 if(wifiScanning){int n=WiFi.scanComplete();if(n>=0){
   wifiNetworks.clear();for(int i=0;i<n;++i){String ssid=WiFi.SSID(i);if(ssid==HMC_AP_NAME)continue;auto auth=WiFi.encryptionType(i);bool supported=auth==WIFI_AUTH_OPEN||auth==WIFI_AUTH_WPA_PSK||auth==WIFI_AUTH_WPA2_PSK||auth==WIFI_AUTH_WPA_WPA2_PSK||auth==WIFI_AUTH_WPA3_PSK||auth==WIFI_AUTH_WPA2_WPA3_PSK;
    wifiNetworks.add(ssid.c_str(),WiFi.RSSI(i),uint8_t(WiFi.channel(i)),auth!=WIFI_AUTH_OPEN,supported);}
   wifiNetworks.sort();WiFi.scanDelete();wifiScanning=false;wifiScanDone=true;wifiScannedAt=now;keyboard.wifiCount=wifiNetworks.count;
   if(!wifiConnected()){Guard g(configLock);for(unsigned i=0;i<wifiNetworks.count;++i)if(cfg.ssid==wifiNetworks.items[i].ssid&&wifiNetworks.items[i].secure&&!cfg.pass.length())wifiLink.fail(hmcwifi::Error::PasswordRequired);}
   if(keyboard.screen==hmcnav::Screen::WifiScan)keyboard.menu=0;
   Serial.printf("[WIFI SCAN] READY / %u networks\n",wifiNetworks.count);
  }else if(n==WIFI_SCAN_FAILED||uint32_t(now-wifiScanStarted)>12000){cancelWifiScan();wifiScanFailed=true;Serial.println("[WIFI SCAN] FAILED");}}
 if(wifiBeginPending&&uint32_t(now-wifiBeginAt)>=600){
  Config c;{Guard g(configLock);c=cfg;}WiFi.disconnect(false,false);wifiDisconnectReason=0;
#if WOKWI_BUILD
  WiFi.begin("Wokwi-GUEST","");
#else
  WiFi.begin(c.ssid.c_str(),c.pass.c_str());
#endif
  wifiBeginPending=false;wifiLink.begin(now);
 }
 auto previous=wifiLink.state;
 if(!wifiBeginPending)wifiLink.tick(wifiConnected(),wifiDisconnectReason.load(),now);
 if(previous!=wifiLink.state){
  Serial.printf("[WIFI] %s / %s\n",hmcwifi::label(wifiLink.state),hmcwifi::message(wifiLink.error));
  if(wifiLink.state==hmcwifi::State::Failed)WiFi.disconnect(false,false);
 }
 if(!wifiScanning&&!wifiBeginPending&&wifiLink.error!=hmcwifi::Error::PasswordRequired&&(wifiLink.state==hmcwifi::State::Failed||wifiLink.state==hmcwifi::State::Disconnected)&&uint32_t(now-wifiRetryAt)>=30000)requestWifiConnection();
 if(wifiDraftActive&&keyboard.screen!=hmcnav::Screen::Compose&&keyboard.screen!=hmcnav::Screen::Confirm){wifiDraftActive=false;wifiDraftSsid="";}
}
