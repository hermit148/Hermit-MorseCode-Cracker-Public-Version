#pragma once
inline constexpr const char *HMC_AP_NAME = "HERMITS MORSECODE CRACKER";
inline constexpr const char *HMC_AP_PASSWORD = "HermitCrack";
